import bpy
import os
import bmesh
import struct
import math
import time
import numpy as np
from struct import unpack,pack
from mathutils import *
from .utils.tristrip import stripify
from .file import *

def Export(context, filepath, use_some_setting, export_type):

    rw_version = 0x36003
    rw_build = 0xffff
    rw_libaray_id = pack_rw_libaray_id(rw_version, rw_build)

    # if export_type in['costume', 'weapon', 'reflect', 'decoy', 'npc', 'type0']:
    scene_collenction = get_scene_collection()
    if not scene_collenction['meshs']:
        print('Please select meshs to export!')
        return {'FINISHED'}
    arm_obj_list = scene_collenction['armatures']
    mesh_list = scene_collenction['meshs']
    if not arm_obj_list:
        arm_obj_list = find_skin_mesh_armatures(mesh_list)
    # arm_obj = arm_obj_list[0]
    for arm_obj in arm_obj_list:
        frame_list = FrameList(arm_obj)
        frame_list.get_frame_list()
        geometry_list = []
        for mesh_obj in mesh_list:
            '''
            arm_mod = None
            is_same_armature = False
            for mod in mesh_obj.modifiers:
                if mod.type == 'ARMATURE':
                    arm_mod = mod
                    break
            if arm_mod is not None:
                cur_arm_obj = arm_mod.object
                if cur_arm_obj == arm_obj:
                    is_same_armature = True
            if is_same_armature:
            '''
            # frame_list.test_rebulid_skeleton()

            # 确保所选的模型和armature是匹配的
            if mesh_obj.parent == arm_obj:
                geo = Geometry(mesh_obj)
                geo.get_mesh_data()
                geo.get_material_list()
                # geo.test_rebulid_mesh()
                if geo.has_skin:
                    geo.update_bone_map(frame_list.hanim_bone_names)
                    if export_type in['costume', 'weapon', 'reflect', 'type0']:
                        geo.get_bone_palette_split_by_material()
                    elif export_type in ['decoy', 'npc']:
                        geo.get_skin_plugin_info()
                geometry_list.append(geo)
        texture_names = get_geometry_list_texture_names(geometry_list)
        num_textures = len(texture_names)
        bs = BinaryStream()
        bs.writeInt(0)
        bs.writeInt(num_textures - 1)

        geometry_count = len(geometry_list)
        clump = Clump(bs,rw_libaray_id, geometry_count, frame_list, geometry_list, export_type)
        clump.write()

        # Mass export
        if len(arm_obj_list) == 1:
            export_name = filepath
        else:
            path = os.path.dirname(filepath)
            export_name = os.path.join(path,arm_obj.name+".dff")

        with open(export_name, 'wb') as f:
            f.write(bs.data)
            f.close()
        print(export_name)
        print("Export done!")
    '''
    elif export_type == 'background':
        # TODO:
        # 1. frame list - done
        # 2. atomic list - done
        # 3. self matrix - ???
        scene_collenction = get_scene_collection()
        if scene_collenction['armatures']:
            armature_obj = scene_collenction['armatures'][0]
            frame_list = FrameList(armature_obj)
            frame_list.get_frame_list()
    '''
    return {'FINISHED'}

rpGEOMETRYTRISTRIP              = 0x00000001
rpGEOMETRYPOSITIONS	            = 0x00000002
rpGEOMETRYTEXTURED	            = 0x00000004
rpGEOMETRYPRELIT	            = 0x00000008
rpGEOMETRYNORMALS	            = 0x00000010
rpGEOMETRYLIGHT	                = 0x00000020
rpGEOMETRYMODULATEMATERIALCOLOR	= 0x00000040
rpGEOMETRYTEXTURED2	            = 0x00000080
rpGEOMETRYMKSKIN                = 0x00000100
rpGEOMETRYNATIVE	            = 0x01000000

class Clump:

    def __init__(self, bs:BinaryStream, rw_libaray_id, geometry_count, \
                frame_list, geometry_list, export_type):
        self.bs = bs
        self.header = RWChunk(RW_Chunks['Clump'], rw_libaray_id)
        self.start_offset = bs.tell()
        self.end_offset = 0
        self.struct = RWChunk(RW_Chunks['Struct'], rw_libaray_id, 12)
        self.num_atomics = geometry_count
        self.geometry_count = geometry_count
        self.num_lights = 0
        self.num_cameras = 0
        self.frame_list : FrameList = frame_list
        self.geometry_list = geometry_list
        self.export_type = export_type
        self.rw_libaray_id = rw_libaray_id
        self.rw_version = unpack_rw_version(rw_libaray_id)
    def write(self):
        self.bs.write(self.header.to_bytes())
        clump_data_offset = self.bs.tell()
        self.bs.write(self.struct.to_bytes())
        self.bs.writeInt(self.num_atomics)
        self.bs.writeInt(self.num_lights)
        self.bs.writeInt(self.num_cameras)

        # Frame List
        has_hanim = False
        if self.frame_list.hanim_bone_list:
            has_hanim = True
        frame_list_header = RWChunk(RW_Chunks['Frame List'], self.rw_libaray_id)
        frame_list_struct = RWChunk(RW_Chunks['Struct'],self.rw_libaray_id)
        frame_count = len(self.frame_list.hierarchical_list)
        if has_hanim:
            frame_count += 2
            hanim_count = len(self.frame_list.hanim_bone_list)
            frame_list_struct.data_size = 56 * frame_count + 4
            frame_list_header.data_size = 12 + frame_list_struct.data_size + 12 + \
                8 + 36 * (frame_count - 1) + hanim_count * 12
        else:
            frame_list_struct.data_size = 56 * frame_count + 4
            frame_list_header.data_size = 12 + frame_list_struct.data_size + \
                12 * frame_count
        self.bs.write(frame_list_header.to_bytes())
        self.bs.write(frame_list_struct.to_bytes())
        self.bs.writeInt(frame_count)
        if has_hanim:
            mat = Matrix()
            mat.identity()
            flat_mat = flat_matrix4x3(mat)

            for m in range(12):
                self.bs.writeFloat(flat_mat[m])
            self.bs.writeInt(-1)
            self.bs.writeInt(3)
            for m in range(12):
                self.bs.writeFloat(flat_mat[m])
            self.bs.writeInt(0)
            self.bs.writeInt(3)
        for frame in self.frame_list.hierarchical_list:
            mat = flat_matrix4x3(frame.matrix_local)
            for m in range(12):
                self.bs.writeFloat(mat[m])
            if has_hanim:
                self.bs.writeInt(frame.parent_index+2)
            else:
                self.bs.writeInt(frame.parent_index)
            self.bs.writeInt(3)

        # HAnim Plugin
        if has_hanim:
            # first null extension
            self.bs.write(RWChunk(RW_Chunks['Extension'],self.rw_libaray_id).to_bytes())

            # second extension
            ext_header = RWChunk(RW_Chunks['Extension'],self.rw_libaray_id)
            hanim_header = RWChunk(RW_Chunks['HAnim PLG'],self.rw_libaray_id)
            hanim_header.data_size = 20 + 12 * hanim_count
            ext_header.data_size = hanim_header.data_size + 12
            self.bs.write(ext_header.to_bytes())
            self.bs.write(hanim_header.to_bytes())
            self.bs.writeInt(256)
            self.bs.writeInt(-1)
            self.bs.writeInt(hanim_count)
            self.bs.writeInt(0)
            self.bs.writeInt(36)
            for ha in self.frame_list.hanim_bone_list:
                self.bs.writeUShort(ha.boneID)
                self.bs.writeUShort(ha.groupID)
                self.bs.writeInt(ha.boneIndex)
                self.bs.writeInt(ha.boneType)

        for frame in self.frame_list.hierarchical_list:
            if has_hanim:
                ext_header = RWChunk(RW_Chunks['Extension'],self.rw_libaray_id, 24)
            else:
                ext_header = RWChunk(RW_Chunks['Extension'],self.rw_libaray_id)
            self.bs.write(ext_header.to_bytes())
            if self.frame_list.hanim_bone_list:
                hanim_header = RWChunk(RW_Chunks['HAnim PLG'],self.rw_libaray_id, 12)
                self.bs.write(hanim_header.to_bytes())
                self.bs.writeInt(256)
                self.bs.writeInt(frame.boneID)
                self.bs.writeInt(0)

        # Geometry List
        geo_list_header = RWChunk(RW_Chunks['Geometry List'],self.rw_libaray_id)
        geo_list_struct = RWChunk(RW_Chunks['Struct'],self.rw_libaray_id, 4)
        self.bs.write(geo_list_header.to_bytes())
        geo_list_data_offst = self.bs.tell()
        self.bs.write(geo_list_struct.to_bytes())
        self.bs.writeInt(self.geometry_count)

        # Geometry
        for mesh in self.geometry_list:
            geo_header = RWChunk(RW_Chunks['Geometry'],self.rw_libaray_id)
            self.bs.write(geo_header.to_bytes())
            geo_data_offset = self.bs.tell()
            geo_struct = RWChunk(RW_Chunks['Struct'],self.rw_libaray_id)
            self.bs.write(geo_struct.to_bytes())
            geometry_native_flag = 1
            if self.export_type == 'type0':
                geometry_native_flag = 0
            flag = rpGEOMETRYTRISTRIP | rpGEOMETRYPOSITIONS | rpGEOMETRYNORMALS | rpGEOMETRYLIGHT
            if mesh.num_uv and self.export_type in \
                ['costume','weapon','decoy','npc','type0','background']:
                flag |= rpGEOMETRYTEXTURED
                if mesh.num_uv > 1:
                    flag |= rpGEOMETRYTEXTURED2
            if mesh.has_colors and not geometry_native_flag:
                flag |= rpGEOMETRYPRELIT
            if mesh.has_skin and not self.export_type == 'background':
                flag |= rpGEOMETRYMKSKIN

            self.bs.writeUShort(flag)
            if geometry_native_flag:
                self.bs.writeUByte(1)
            else:
                self.bs.writeUByte(mesh.num_uv)
            self.bs.writeUByte(geometry_native_flag)
            self.bs.writeUInt(len(mesh.faces))
            self.bs.writeUInt(len(mesh.vertices))
            self.bs.writeInt(1)     # num morph targets
            if not geometry_native_flag:
                if flag & rpGEOMETRYPRELIT:
                    for color in mesh.colors:
                        self.bs.writeUByte(color[0])
                        self.bs.writeUByte(color[1])
                        self.bs.writeUByte(color[2])
                        self.bs.writeUByte(color[3])
                if flag & rpGEOMETRYTEXTURED or flag & rpGEOMETRYTEXTURED2:
                    for uv in mesh.uv1s:
                        self.bs.writeFloat(uv[0])
                        self.bs.writeFloat(1-uv[1])
                if flag & rpGEOMETRYTEXTURED2:
                    for uv in mesh.uv2s:
                        self.bs.writeFloat(uv[0])
                        self.bs.writeFloat(1-uv[1])
                for i,face in enumerate(mesh.faces):
                    self.bs.writeUShort(face[0])
                    self.bs.writeUShort(face[1])
                    self.bs.writeUShort(face[2])
                    self.bs.writeUShort(mesh.face_matid_list[i])
            minx=miny=minz = 0
            maxx=maxy=maxz = 0
            for vertex in mesh.vertices:
                if vertex[0] < minx:
                    minx = vertex[0]
                if vertex[1] < miny:
                    miny = vertex[1]
                if vertex[2] < minz:
                    minz = vertex[2]
                if vertex[0] > maxx:
                    maxx = vertex[0]
                if vertex[1] > maxy:
                    maxy = vertex[1]
                if vertex[2] > maxz:
                    maxz = vertex[2]
            sphere_center_x = (maxx + minx) * 0.5
            sphere_center_y = (maxy + miny) * 0.5
            sphere_center_z = (maxz + minz) * 0.5
            sphere_radius = (Vector((maxx,maxy,maxz)) - \
                            Vector((minx,miny,minz))).length * 0.5
            self.bs.writeFloat(sphere_center_x)
            self.bs.writeFloat(sphere_center_y)
            self.bs.writeFloat(sphere_center_z)
            self.bs.writeFloat(sphere_radius)
            if not geometry_native_flag:
                self.bs.writeInt(1)
                self.bs.writeInt(1)
            else:
                self.bs.writeInt(0)
                self.bs.writeInt(0)
            if not geometry_native_flag:
                pad16_length1 = get_padding_length(self.bs.tell(), 16)
                pad16_length2 = 16 - pad16_length1
                pad16_bytes = "PAD16".encode('ASCII')
                for p in range(pad16_length1):
                    pad_pos = p % len(pad16_bytes)
                    self.bs.writeUByte(pad16_bytes[pad_pos])
                for vertex in mesh.vertices:
                    self.bs.writeFloat(vertex[0])
                    self.bs.writeFloat(vertex[1])
                    self.bs.writeFloat(vertex[2])
                for p in range(pad16_length2):
                    pad_pos = p % len(pad16_bytes)
                    self.bs.writeUByte(pad16_bytes[pad_pos])
                pad16_length1 = get_padding_length(self.bs.tell(), 16)
                pad16_length2 = 16 - pad16_length1
                for p in range(pad16_length1):
                    pad_pos = p % len(pad16_bytes)
                    self.bs.writeUByte(pad16_bytes[pad_pos])
                for normal in mesh.normals:
                    self.bs.writeFloat(normal[0])
                    self.bs.writeFloat(normal[1])
                    self.bs.writeFloat(normal[2])
                for p in range(pad16_length2):
                    pad_pos = p % len(pad16_bytes)
                    self.bs.writeUByte(pad16_bytes[pad_pos])
                geo_struct_end = self.bs.tell()
                geo_struct.data_size = geo_struct_end - geo_data_offset - 12
                self.bs.seek(geo_data_offset + 4)
                self.bs.writeUInt(geo_struct.data_size)
                self.bs.seek(geo_struct_end)
            #mesh_type = 0
            #if geometry_native_flag:
            if self.export_type in['costume','weapon']:
                mesh_type = 128 if mesh.has_skin else 137
            elif self.export_type == 'reflect':
                mesh_type = 130
            elif self.export_type in ['decoy','npc']:
                mesh_type = 131 if mesh.has_skin else 137
            elif self.export_type in ['background']:
                mesh_type = 137
            elif self.export_type in ['type0']:
                mesh_type = 0
            # Material List
            mat_list_header = RWChunk(RW_Chunks['Material List'],self.rw_libaray_id)
            mat_list_struct = RWChunk(RW_Chunks['Struct'], self.rw_libaray_id)
            mat_list_struct.data_size = 4 + len(mesh.material_list) * 4
            self.bs.write(mat_list_header.to_bytes())
            mat_list_data_offset = self.bs.tell()
            self.bs.write(mat_list_struct.to_bytes())

            self.bs.writeInt(len(mesh.material_list))
            for m in range(len(mesh.material_list)):
                self.bs.writeInt(-1)

            # Material
            for i,mat in enumerate(mesh.material_list):
                mat_header = RWChunk(RW_Chunks['Material'], self.rw_libaray_id)
                mat_struct = RWChunk(RW_Chunks['Struct'], self.rw_libaray_id, 28)
                self.bs.write(mat_header.to_bytes())
                mat_data_offset = self.bs.tell()
                self.bs.write(mat_struct.to_bytes())
                self.bs.writeInt(0)
                self.bs.writeInt(-1)
                self.bs.writeInt(0)
                self.bs.writeInt(mat.rw.has_texture)
                self.bs.writeFloat(mat.rw.ambient)
                self.bs.writeFloat(mat.rw.specular)
                self.bs.writeFloat(mat.rw.diffuse)
                if mat.rw.has_texture:
                    texture_header = RWChunk(RW_Chunks['Texture'], self.rw_libaray_id)
                    texture_struct = RWChunk(RW_Chunks['Struct'], self.rw_libaray_id, 4)
                    self.bs.write(texture_header.to_bytes())
                    texture_data_offset = self.bs.tell()
                    self.bs.write(texture_struct.to_bytes())
                    flag = int(mat.rw.texture_filter)
                    flag |= (int(mat.rw.v_addressing) << 4 | int(mat.rw.u_addressing)) << 8
                    flag |= 1 << 16
                    self.bs.writeInt(flag)
                    tex_name_header = RWChunk(RW_Chunks['String'], self.rw_libaray_id)
                    tex_name_bytes = mat.rw.texture_name.encode('ASCII')
                    pad4_length = get_padding_length(len(tex_name_bytes) + 1, 4)
                    tex_name_header.data_size = len(tex_name_bytes) + 1 + pad4_length
                    self.bs.write(tex_name_header.to_bytes())
                    self.bs.write(tex_name_bytes)
                    for p in range(pad4_length + 1):
                        self.bs.writeByte(0)
                    alpha_header = RWChunk(RW_Chunks['String'], self.rw_libaray_id, 4)
                    self.bs.write(alpha_header.to_bytes())
                    self.bs.writeInt(0)
                    texture_ext = RWChunk(RW_Chunks['Extension'], self.rw_libaray_id, 16)
                    SkyMipmapVal_header = RWChunk(RW_Chunks['Sky Mipmap Val'],\
                                            self.rw_libaray_id, 4)
                    self.bs.write(texture_ext.to_bytes())
                    self.bs.write(SkyMipmapVal_header.to_bytes())
                    self.bs.writeInt((mat.rw.PS2_SkyMipmapVal_L << 12) |\
                                    mat.rw.PS2_SkyMipmapVal_K)
                    tex_end = self.bs.tell()
                    texture_header.data_size = tex_end - texture_data_offset
                    self.bs.seek(texture_data_offset - 8)
                    self.bs.writeInt(tex_name_header.data_size)
                    self.bs.seek(tex_end)
                mat_ext_header = RWChunk(RW_Chunks['Extension'], self.rw_libaray_id)
                mkmaterial_header = RWChunk(RW_Chunks['RpMaterial MkMaterial Plugin'],\
                                    self.rw_libaray_id)
                self.bs.write(mat_ext_header.to_bytes())
                mat_ext_data_offset = self.bs.tell()
                self.bs.write(mkmaterial_header.to_bytes())
                mkmaterial_data_offset = self.bs.tell()
                if mat.mk.type != 5:
                    mat.mk.type = 5
                flag = mat.mk.type
                if mesh.has_skin and self.export_type in ['costume','weapon','reflect','type0']:
                    flag |= 0x60000000
                if mat.mk.uv_scroll:
                    flag |= 0x80000000
                self.bs.writeInt(flag)
                self.bs.writeShort(mat.mk.unk1)
                self.bs.writeShort(mat.mk.unk2)
                self.bs.writeFloat(mat.mk.unk3)
                if flag & 0x40000000 and mat.mk.type >= 2:
                    num_boneids = len(mesh.bone_palettes_split_by_material[i])
                    self.bs.writeInt(num_boneids)
                    for bid in mesh.bone_palettes_split_by_material[i]:
                        self.bs.writeInt(bid)
                if mat.mk.type >= 3:
                    self.bs.writeUByte(mat.mk.spec_r)
                    self.bs.writeUByte(mat.mk.spec_g)
                    self.bs.writeUByte(mat.mk.spec_b)
                    self.bs.writeUByte(mat.mk.spec_a)
                if mat.mk.type >= 4:
                    self.bs.writeFloat(mat.mk.unk5)
                    self.bs.writeFloat(mat.mk.unk6)
                    if flag & 0x80000000:
                        self.bs.writeFloat(mat.mk.uv_scroll_speed_x)
                        self.bs.writeFloat(mat.mk.uv_scroll_speed_y)
                        self.bs.writeFloat(mat.mk.uv_scroll_speed_z)
                        self.bs.writeFloat(0)
                if mat.mk.type >= 5:
                    self.bs.writeInt(mesh_type)
                mat_end = self.bs.tell()
                mkmaterial_header.data_size = mat_end - mkmaterial_data_offset
                self.bs.seek(mkmaterial_data_offset - 8)
                self.bs.writeInt(mkmaterial_header.data_size)
                mat_ext_header.data_size = mat_end - mat_ext_data_offset
                self.bs.seek(mat_ext_data_offset - 8)
                self.bs.writeInt(mat_ext_header.data_size)
                mat_header.data_size = mat_end - mat_data_offset
                self.bs.seek(mat_data_offset - 8)
                self.bs.writeUInt(mat_header.data_size)
                self.bs.seek(mat_end)
            mat_list_end = self.bs.tell()
            mat_list_header.data_size = mat_list_end - mat_list_data_offset
            self.bs.seek(mat_list_data_offset - 8)
            self.bs.writeUInt(mat_list_header.data_size)
            self.bs.seek(mat_list_end)

            geo_ext_header = RWChunk(RW_Chunks['Extension'], self.rw_libaray_id)
            self.bs.write(geo_ext_header.to_bytes())
            geo_ext_data_offset = self.bs.tell()

            strips_group = []
            strips_skiplist_group = []
            if geometry_native_flag:
                split_count = len(mesh.face_group_split_matids)
                # Divide the triangle strip according to the specified number
                # The maximum number of vertices is 38
                for i in range(split_count):
                    strip = mesh.tristrip_groups[i]
                    skip_list = []
                    skip_count = 0
                    for index,v in enumerate(strip):
                        if index > 2:
                            f1 = strip[index-2]
                            f2 = strip[index-1]
                            f3 = v
                            if f1 != f2 and f2 != f3 and f3 != f1:
                                skip_list.append(0)
                            else:
                                skip_list.append(1)
                                skip_count += 1
                        else:
                            skip_list.append(0)
                    skiplists = []
                    strips = []
                    split_number = 34
                    strip_indices_count = len(strip)
                    count = strip_indices_count // split_number
                    has_last = strip_indices_count % split_number > 0
                    last_count = strip_indices_count % split_number

                    for s in range(count):
                        if s == 0:
                            temp_strip = strip[0:split_number]
                            strips.append(temp_strip)
                            temp_skiplist = skip_list[0:split_number]
                            skiplists.append(temp_skiplist)
                        else:
                            temp_strip = strip[s*split_number-2:\
                                        s*split_number + split_number]
                            strips.append(temp_strip)
                            temp_skiplist = skip_list[s*split_number-2:\
                                            s*split_number + split_number]
                            skiplists.append(temp_skiplist)
                    if has_last and count: # last strip
                        temp_strip = strip[count*split_number-2:\
                                        count*split_number + last_count]
                        strips.append(temp_strip)
                        temp_skiplist = skip_list[count*split_number-2:\
                                        count*split_number + last_count]
                        skiplists.append(temp_skiplist)
                    elif not count: # only strip number < split_number
                        temp_strip = strip[0:last_count]
                        strips.append(temp_strip)
                        temp_skiplist = skip_list[0:last_count]
                        skiplists.append(temp_skiplist)
                    strips_group.append(strips)
                    strips_skiplist_group.append(skiplists)



            # Bin Mesh Plugin
            bin_mesh_plg_header = RWChunk(RW_Chunks['Bin Mesh PLG'], self.rw_libaray_id)
            self.bs.write(bin_mesh_plg_header.to_bytes())
            bin_mesh_plg_data_offset = self.bs.tell()
            face_type = 1   # tri-strip = 1, tri-list = 0
            split_count = len(mesh.face_group_split_matids)
            self.bs.writeInt(face_type)
            self.bs.writeInt(split_count)
            self.bs.writeUInt(mesh.face_indices_count)
            for idx,(matid,indices) in enumerate(zip(mesh.face_group_split_matids,\
                                                     mesh.tristrip_groups)):
                if not geometry_native_flag:
                    self.bs.writeUInt(len(indices))
                else:
                    count = 0
                    for strip in strips_group[idx]:
                        count += len(strip)
                    self.bs.writeUInt(count)
                self.bs.writeUInt(matid)
                if not geometry_native_flag:
                    for index in indices:
                        self.bs.writeUInt(index)
            bin_mesh_plg_end = self.bs.tell()
            bin_mesh_plg_header.data_size = bin_mesh_plg_end - bin_mesh_plg_data_offset
            self.bs.seek(bin_mesh_plg_data_offset - 8)
            self.bs.writeUInt(bin_mesh_plg_header.data_size)
            self.bs.seek(bin_mesh_plg_end)


            if not geometry_native_flag and mesh.has_skin:
                # Skin Plugin
                skin_plg_header = RWChunk(RW_Chunks['Skin PLG'], self.rw_libaray_id)
                self.bs.write(skin_plg_header.to_bytes())
                skin_plg_data_offset = self.bs.tell()
                self.bs.writeUByte(len(self.frame_list.hanim_bone_list))
                self.bs.writeUByte(mesh.num_used_bones)
                self.bs.writeUByte(mesh.max_weights_per_vertex)
                self.bs.writeByte(0)
                for i in range(mesh.num_used_bones):
                    self.bs.writeUByte(i)
                for boneids in mesh.mk_boneids:
                    for idx in range(4):
                        if idx < len(boneids):
                            self.bs.writeUByte(boneids[idx])
                        else:
                            self.bs.writeUByte(0)
                for weights in mesh.weights:
                    for wt in range(4):
                        if wt < len(weights):
                            self.bs.writeFloat(weights[wt])
                        else:
                            self.bs.writeFloat(0)
                mesh_mat = self.frame_list.hanim_bone_list[0].matrix_world
                mesh_mat.invert()
                for hanim_frame in self.frame_list.hanim_bone_list:
                    mat = hanim_frame.matrix_world
                    mat = mesh_mat @ mat
                    for r in range(3):
                        for c in range(4):
                            self.bs.writeFloat(mat[r][c])
                    self.bs.writeFloat(-mat[3][0])
                    self.bs.writeFloat(-mat[3][1])
                    self.bs.writeFloat(-mat[3][2])
                    self.bs.writeFloat(1.0)
                self.bs.writeInt(0)
                self.bs.writeInt(0)
                self.bs.writeInt(0)
                skin_plg_end = self.bs.tell()
                skin_plg_header.data_size = skin_plg_end - skin_plg_data_offset
                self.bs.seek(skin_plg_data_offset - 8)
                self.bs.writeUInt(skin_plg_header.data_size)
                self.bs.seek(skin_plg_end)

            geo_ext_end = self.bs.tell()
            geo_ext_header.data_size = geo_ext_end - geo_ext_data_offset
            self.bs.seek(geo_ext_data_offset - 8)
            self.bs.writeUInt(geo_ext_header.data_size)
            self.bs.seek(geo_ext_end)
            # print("before strips:",mesh.face_indices_count)
            current_strips_count = 0
            if geometry_native_flag:
                temp_vert_count = 0
                native_data_offset = self.bs.tell()
                for i in range(split_count):
                    self.bs.writeUInt(0)
                    self.bs.writeUInt(1)
                    strip_data_offset = self.bs.tell()

                    pad128_length1 = get_padding_length(self.bs.tell(), 128)
                    pad128_length2 = 128 - pad128_length1
                    pad128_bytes = "PAD128".encode('ASCII')
                    for p in range(pad128_length1):
                        self.bs.writeUByte(pad128_bytes[p % len(pad128_bytes)])
                    # DMA Tag
                    self.bs.writeUShort(0)
                    self.bs.writeUShort(0x6000)
                    self.bs.writeInt(0)
                    # VIFCODE
                    # STMOD
                    self.bs.writeUInt(0x05000000)
                    dmatag_offset = self.bs.tell() + 4
                    strips = strips_group[i]
                    skiplists = strips_skiplist_group[i]
                    for j,strip in enumerate(strips):
                        temp_vertices = []
                        temp_normals = []
                        temp_uv1s = []
                        temp_uv1s_float = []
                        temp_colors = []
                        temp_boneids = []
                        temp_weights = []
                        skip_list = skiplists[j]
                        skip_count = 0
                        for index,v in enumerate(strip):
                            temp_vertices.append(mesh.vertices[v])
                            normal = mesh.normals[v]
                            normal = (int(normal[0]*127.0), int(normal[1]*127.0), \
                                    int(normal[2]*127.0))
                            temp_normals.append(normal)
                            if mesh.num_uv:
                                uv = mesh.uv1s[v]
                                temp_uv1s_float.append(uv)
                                uv = (int(uv[0]*4096.0), int((1-uv[1])*4096.0))
                                temp_uv1s.append(uv)
                            if mesh.has_colors:
                                temp_colors.append(mesh.colors[v])
                            if mesh.has_skin:
                                temp_boneids.append(mesh.mk_boneids[v])
                                temp_weights.append(mesh.weights[v])
                        current_strips_count += len(strip)
                        num_vert = len(strip)
                        vertex_index_list = []
                        for v in range(num_vert):
                            if mesh.has_skin:
                                if mesh_type == 128:
                                    if not j & 1:
                                        index = v * 4 + 130
                                    else:
                                        index = v * 4 + 488
                                elif mesh_type == 131:
                                    if not j & 1:
                                        index = v * 3 + 191
                                    else:
                                        index = v * 3 + 634
                            else:
                                # mesh type 137
                                if not j & 1:
                                    index = v * 5 + 193
                                else:
                                    index = v * 5 + 671
                            if skip_list[v]:
                                index |= 0x8000
                            vertex_index_list.append((index))
                        # Sort the vertex storage order based on the number of
                        # bone weights used by the vertices.
                        if mesh.has_skin and self.export_type in ['costume','weapon','npc','decoy']:
                            sorted_vertices = []
                            sorted_normals = []
                            sorted_uv1s = []
                            sorted_boneids = []
                            sorted_weights = []
                            sorted_vertex_index_list = []
                            for wi in range(1,4):
                                for idx,boneids in enumerate(temp_boneids):
                                    if len(boneids) == wi:
                                        sorted_vertices.append(temp_vertices[idx])
                                        sorted_normals.append(temp_normals[idx])
                                        if mesh.num_uv:
                                            sorted_uv1s.append(temp_uv1s[idx])
                                        if mesh.has_skin:
                                            sorted_boneids.append(temp_boneids[idx])
                                            sorted_weights.append(temp_weights[idx])
                                        sorted_vertex_index_list.append(vertex_index_list[idx])
                            temp_vertices = sorted_vertices
                            temp_normals = sorted_normals
                            if mesh.num_uv:
                                temp_uv1s = sorted_uv1s
                            if mesh.has_skin:
                                temp_boneids = sorted_boneids
                                temp_weights = sorted_weights
                            vertex_index_list = sorted_vertex_index_list


                        if self.export_type in ['costume','weapon','npc','decoy','background']:
                            self.bs.writeUInt(0x01000101)   # 0x1 STCYCL
                            if mesh.has_skin:
                                use1bones_count,use2bones_count,use3bones_count =  \
                                    get_used_bone_count(temp_boneids)

                                self.bs.writeUInt(0x6E02C000)   # 0x6E header info
                                # no reuse vertices number info
                                self.bs.writeUByte(use1bones_count)   # 1 bones vertices number
                                self.bs.writeUByte(use2bones_count)   # 2 bones vertices number
                                self.bs.writeUByte(use3bones_count)   # 3 bones vertices number
                                self.bs.writeUByte(num_vert)

                                # reuse vertices number info
                                self.bs.writeUByte(0)   # 1 bones vertices number
                                self.bs.writeUByte(0)   # 2 bones vertices number
                                self.bs.writeUByte(0)   # 3 bones vertices number
                                self.bs.writeUByte(0)   # used shared vertex count
                            else:
                                self.bs.writeInt(0x6C018000)
                                boundsphere = get_bounding_sphere_xyz_radidus(temp_vertices)
                                self.bs.writeFloat(boundsphere.center_x)
                                self.bs.writeFloat(boundsphere.center_y)
                                self.bs.writeFloat(boundsphere.center_z)
                                self.bs.writeFloat(boundsphere.radius)
                                self.bs.writeUInt(0x6E01C001)   # 0x6E header info
                                self.bs.writeUByte(num_vert)    # no reuse vertices number
                                self.bs.writeUByte(0)           # reuse vertices number
                                self.bs.writeUByte(0)
                                self.bs.writeUByte(num_vert)

                        self.bs.writeUInt(0x1000103)   # 0x1 STCYCL
                        # 0x68 Vectices
                        addr = 0
                        if mesh_type == 128:
                            addr = 15
                        elif mesh_type == 137:
                            addr = 17
                        elif mesh_type == 131:
                            addr = 22
                        elif mesh_type == 130:
                            addr = 0
                        vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0x8, 'float',temp_vertices)
                        data = vif_unpack.write()
                        if mesh.has_skin and mesh_type in [128,128,131]:
                            bs = BinaryStream()
                            bi = BinaryStream(data)
                            for v in range(len(temp_vertices)):
                                vx = bi.readUInt() & 0xFFFFFC00
                                vy = bi.readUInt() & 0xFFFFFC00
                                vz = bi.readUInt() & 0xFFFFFC00
                                boneid_1 = (temp_boneids[v][0] + 1) * 4
                                boneid_2 = 0
                                boneid_3 = 0
                                if len(temp_boneids[v]) > 1:
                                    boneid_2 = (temp_boneids[v][1] + 1) * 4
                                if len(temp_boneids[v]) > 2:
                                    boneid_3 = (temp_boneids[v][2] + 1) * 4
                                bs.writeUInt(vx | (boneid_1 & 0x3FF))
                                bs.writeUInt(vy | (boneid_2 & 0x3FF))
                                bs.writeUInt(vz | (boneid_3 & 0x3FF))
                            data = bs.getBuffer()
                        self.bs.writeUInt(vif_unpack.encode())
                        self.bs.write(data)

                        # 0x6E BoneID / Skip Flag chunk. REFLECT
                        addr = 0
                        if mesh_type == 130:
                            addr = 1
                        if self.export_type == 'reflect':
                            temp_boneids_skiplist = []
                            for idx,boneids in enumerate(temp_boneids):
                                temp_data = []
                                max_weight = 0.0
                                max_boneid = 0
                                for bidx,w in enumerate(temp_weights[idx]):
                                    if w > max_weight:
                                        max_weight = w
                                        max_boneid = boneids[bidx]
                                temp_data.append((max_boneid + 1) * 4)
                                temp_data.append(0)
                                temp_data.append(0)
                                temp_data.append(skip_list[idx])
                                temp_boneids_skiplist.append(temp_data)
                            vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0xE, 'ubyte',\
                                                            temp_boneids_skiplist)
                            data = vif_unpack.write()
                            self.bs.writeUInt(vif_unpack.encode())
                            self.bs.write(data)

                        # 0x6A Normals
                        addr = 0
                        if mesh_type == 128:
                            addr = 16
                        elif mesh_type == 137:
                            addr = 18
                        elif mesh_type == 131:
                            addr = 23
                        elif mesh_type == 130:
                            addr = 2
                        vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0xA, 'byte',temp_normals)
                        data = vif_unpack.write()
                        self.bs.writeUInt(vif_unpack.encode())
                        self.bs.write(data)

                        # 0x65 UV
                        addr = 0
                        if mesh_type == 128:
                            addr = 17
                        elif mesh_type == 131:
                            addr = 24
                        if mesh.num_uv and mesh_type in [128,129,131]:
                            vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0x5, 'short',temp_uv1s)
                            data = vif_unpack.write()
                            self.bs.writeUInt(vif_unpack.encode())
                            self.bs.write(data)

                        # 0x64 UV
                        addr = 0
                        if mesh_type == 137:
                            addr = 19
                        if mesh_type == 137: # [137,132,135]
                            vif_unpack = EncodePS2VIFUnpack(num_vert, addr,\
                                                             0x4, 'float',temp_uv1s_float)
                            data = vif_unpack.write()
                            self.bs.writeUInt(vif_unpack.encode())
                            self.bs.write(data)

                        # 0x6E Colors
                        addr = 0
                        if mesh_type == 137:
                            addr = 20
                            if not mesh.has_colors:
                                temp_colors = []
                                for v in range(num_vert):
                                    color = (0,0,0,255)
                                    temp_colors.append(color)
                            vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0xE, 'ubyte',\
                                                            temp_colors)
                            data = vif_unpack.write()
                            self.bs.writeUInt(vif_unpack.encode())
                            self.bs.write(data)

                        self.bs.writeUInt(0x20000000)   # 0x20 STMASK
                        self.bs.writeUInt(0xCFCFCFCF)   # MASK

                        # [128,129,131,137,133,136,138,141]
                        if mesh_type in [128,131,137]:
                            # 0x71 Strip Vertex Index List 1
                            addr = 0
                            if mesh_type in[128,137]:
                                addr = 17
                            elif mesh_type == 131:
                                addr = 24
                            vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0x1,\
                                                            'ushort',vertex_index_list)
                            vif_unpack.m = 1
                            vif_unpack.unsignd = 0
                            data = vif_unpack.write()
                            self.bs.writeUInt(vif_unpack.encode())
                            self.bs.write(data)
                            self.bs.writeUInt(0x20000000)   # 0x20 STMASK
                            self.bs.writeUInt(0x3F3F3F3F)   # MASK
                            if mesh.has_skin and not self.export_type == 'background':
                                weight1_list = []
                                weight2_list = []
                                for w in temp_weights:
                                    if len(w) == 1:
                                        weight1_list.append((4096))
                                        weight2_list.append((0))
                                    elif len(w) > 1:
                                        weight1_list.append(int(w[0]*4096))
                                        weight2_list.append(int(w[1]*4096))

                                # 0x71 Bone Weight Chunk 1
                                addr = 0
                                if mesh_type == 128:
                                    addr = 15
                                elif mesh_type == 131:
                                    addr = 22
                                vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0x1,\
                                            'ushort',weight1_list)
                                data = vif_unpack.write()
                                vif_unpack.m = 1
                                vif_unpack.unsignd = 0
                                self.bs.writeUInt(vif_unpack.encode())
                                self.bs.write(data)

                                # 0x71 Bone Weight Chunk 2
                                addr = 0
                                if mesh_type == 128:
                                    addr = 16
                                elif mesh_type == 131:
                                    addr = 23
                                vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0x1, \
                                            'ushort',weight2_list)
                                vif_unpack.m = 1
                                vif_unpack.unsignd = 0
                                data = vif_unpack.write()
                                self.bs.writeUInt(vif_unpack.encode())
                                self.bs.write(data)
                            # 0x71 Strip Vertex Index List 2
                            addr = 0
                            if mesh_type == 128:
                                addr = 17
                            elif mesh_type == 137:
                                addr = 18
                            elif mesh_type == 131:
                                addr = 24
                            vif_unpack = EncodePS2VIFUnpack(num_vert, addr, 0x1,\
                                        'ushort',vertex_index_list)
                            vif_unpack.m = 1
                            vif_unpack.unsignd = 0
                            data = vif_unpack.write()
                            self.bs.writeUInt(vif_unpack.encode())
                            self.bs.write(data)

                        self.bs.writeInt(0x01000101)   # 0x1 STCYCL
                        self.bs.writeInt(0x20000000)   # 0x20 STMASK
                        self.bs.writeInt(0)            # mask
                        temp_vert_count += num_vert
                        if mesh_type == 130:
                            self.bs.writeInt(0x4000000 | num_vert)       # 0x4 ITOP
                        else:
                            if j == 0:
                                self.bs.writeInt(0x4000000)
                            else:
                                self.bs.writeInt(0x4000000 | temp_vert_count & 1)   # 0x4 ITOP
                        if j == 0:
                            self.bs.writeInt(0x14000000)    # 0x14 MSCAL
                        else:
                            self.bs.writeInt(0x17000000)    # 0x17 MSCNT
                    self.bs.writeInt(0x11000000)    # 0x11 FLUSH
                    pad16_length = get_padding_length(self.bs.tell(), 16)
                    for p in range(pad16_length):
                        self.bs.writeByte(0)
                    dma_pack_end = self.bs.tell()
                    dma_qword_count = (dma_pack_end - dmatag_offset) // 16
                    self.bs.seek(dmatag_offset - 16)
                    self.bs.writeUShort(dma_qword_count)
                    self.bs.seek(dma_pack_end)

                    for p in range(pad128_length2):
                        self.bs.writeUByte(pad128_bytes[p % len(pad128_bytes)])
                    vif_end = self.bs.tell()
                    vif_size = vif_end - strip_data_offset
                    self.bs.seek(strip_data_offset - 8)
                    self.bs.writeUInt(vif_size)
                    self.bs.seek(vif_end)
                    # print("current strips index count",current_strips_count)
                if mesh.has_skin and mesh_type in [128,131,130]:
                    # Native Skin Plugin
                    skin_plg_header = RWChunk(RW_Chunks['Struct'], self.rw_libaray_id, 0xFFFFFFF4)
                    self.bs.write(skin_plg_header.to_bytes())
                    self.bs.writeInt(4)     # PS2 platform = 4
                    self.bs.writeUByte(len(self.frame_list.hanim_bone_list))
                    self.bs.writeUByte(mesh.num_used_bones)
                    self.bs.writeUByte(mesh.max_weights_per_vertex)
                    self.bs.writeByte(0)
                    for i in range(mesh.num_used_bones):
                        if mesh_type in[130,131] :
                            self.bs.writeUByte(mesh.used_bones[i])
                        else:
                            self.bs.writeUByte(i)

                    mesh_mat = self.frame_list.hanim_bone_list[0].matrix_world
                    mesh_mat.invert()
                    for hanim_frame in self.frame_list.hanim_bone_list:
                        mat = hanim_frame.matrix_world
                        mat = mesh_mat @ mat
                        for r in range(3):
                            for c in range(4):
                                self.bs.writeFloat(mat[r][c])
                        self.bs.writeFloat(-mat[3][0])
                        self.bs.writeFloat(-mat[3][1])
                        self.bs.writeFloat(-mat[3][2])
                        self.bs.writeFloat(1.0)
                    self.bs.writeInt(0)
                    self.bs.writeInt(0)
                    self.bs.writeInt(0)
                    self.bs.writeInt(0)
                navtive_end = self.bs.tell()
                geo_struct.data_size = 0x28 + (navtive_end - native_data_offset)
                self.bs.seek(geo_data_offset + 4)
                self.bs.writeUInt(geo_struct.data_size)
                self.bs.seek(navtive_end)
            geo_end = self.bs.tell()
            geo_header.data_size = geo_end - geo_data_offset
            self.bs.seek(geo_data_offset - 8)
            self.bs.writeUInt(geo_header.data_size)
            self.bs.seek(geo_end)
        geo_list_end = self.bs.tell()
        geo_list_header.data_size = geo_list_end - geo_list_data_offst
        self.bs.seek(geo_list_data_offst - 8)
        self.bs.writeUInt(geo_list_header.data_size)
        self.bs.seek(geo_list_end)
        for i in range(self.geometry_count):
            frame_index = 0
            if self.export_type in ['background','type0']:
                if self.geometry_list[i].has_skin:
                    frame_index = 0 # type 0 skin model
                else:
                    if self.geometry_list[i].meshobj.parent_type == 'BONE':
                        # print(self.geometry_list[i].meshobj.parent_bone)
                        parent_name = self.geometry_list[i].meshobj.parent_bone
                        frame_index = self.frame_list.hierarchical_names.index(parent_name)
                        if has_hanim:
                            frame_index += 2
                    elif self.geometry_list[i].meshobj.parent_type == 'OBJECT':
                        # print(self.geometry_list[i].meshobj.parent.name)
                        frame_index = 0

            atomic_header = RWChunk(RW_Chunks['Atomic'], self.rw_libaray_id)
            self.bs.write(atomic_header.to_bytes())
            atomic_data_offset = self.bs.tell()
            atomic_struct = RWChunk(RW_Chunks['Struct'], self.rw_libaray_id, 16)
            self.bs.write(atomic_struct.to_bytes())
            self.bs.writeUInt(frame_index)
            self.bs.writeUInt(i)
            self.bs.writeUInt(5)
            self.bs.writeUInt(0)
            atomic_ext_header = RWChunk(RW_Chunks['Extension'], self.rw_libaray_id, 48)
            self.bs.write(atomic_ext_header.to_bytes())
            right_to_render_header = RWChunk(RW_Chunks['Right to Render'], \
                                    self.rw_libaray_id, 8)
            self.bs.write(right_to_render_header.to_bytes())
            self.bs.writeInt(278)
            self.bs.writeInt(1)
            mksobj_plugin_header = RWChunk(RW_Chunks['RpAtomic Mksobj Plugin'],\
                                self.rw_libaray_id, 16)
            self.bs.write(mksobj_plugin_header.to_bytes())
            self.bs.writeUInt(3)
            self.bs.writeUInt(0)
            self.bs.writeFloat(0)
            mesh_type = 0
            if geometry_native_flag:
                if self.export_type in['costume','weapon']:
                    mesh_type = 128 if self.geometry_list[i].has_skin else 137
                elif self.export_type == 'reflect':
                    mesh_type = 130
                elif self.export_type in ['decoy','npc']:
                    mesh_type = 131 if self.geometry_list[i].has_skin else 137
                elif self.export_type in ['background']:
                    mesh_type = 137
            self.bs.writeInt(mesh_type)
            atomic_end = self.bs.tell()
            atomic_header.data_size = atomic_end - atomic_data_offset
            self.bs.seek(atomic_data_offset - 8)
            self.bs.writeUInt(atomic_header.data_size)
            self.bs.seek(atomic_end)
        clump_ext_header = RWChunk(RW_Chunks['Extension'], self.rw_libaray_id)
        self.bs.write(clump_ext_header.to_bytes())
        clump_end = self.bs.tell()
        self.header.data_size = clump_end - clump_data_offset
        self.bs.seek(self.start_offset + 4)
        self.bs.writeUInt(self.header.data_size)
        self.bs.seek(clump_end)
        pad128_length = get_padding_length(self.bs.tell(), 128)
        pad128_bytes = "PAD128".encode('ASCII')
        for i in range(pad128_length):
            self.bs.writeUByte(pad128_bytes[i % len(pad128_bytes)])
def get_used_bone_count(boneids):
    count1 = 0
    count2 = 0
    count3 = 0
    for indices in boneids:
        if len(indices) == 1:
            count1 += 1
        elif len(indices) == 2:
            count2 += 1
        elif len(indices) == 3:
            count3 += 1
        else:
            count3 += 1 # need to correct > 3 weights
    return (count1,count2,count3)
class BoudingSphere:
    def __init__(self, x, y, z, r):
        self.center_x = x
        self.center_y =  y
        self.center_z =  z
        self.radius = r
def get_bounding_sphere_xyz_radidus(vertices):
    minx=miny=minz = 0
    maxx=maxy=maxz = 0
    for vertex in vertices:
        if vertex[0] < minx:
            minx = vertex[0]
        if vertex[1] < miny:
            miny = vertex[1]
        if vertex[2] < minz:
            minz = vertex[2]
        if vertex[0] > maxx:
            maxx = vertex[0]
        if vertex[1] > maxy:
            maxy = vertex[1]
        if vertex[2] > maxz:
            maxz = vertex[2]
    sphere_center_x = (maxx + minx) * 0.5
    sphere_center_y = (maxy + miny) * 0.5
    sphere_center_z = (maxz + minz) * 0.5
    sphere_radius = (Vector((maxx,maxy,maxz)) - \
                    Vector((minx,miny,minz))).length * 0.5
    return BoudingSphere(sphere_center_x,sphere_center_y,sphere_center_z,sphere_radius)
'''
    VIFCODE UNPACK
    vn+vl;
    CMD     vn vl Format No. of elements (Dimension) Data length Alignment 
    i11m0000 00 00 0    S-32     1 32 bits
    i11m0001 00 01 1    S-16     1 16 bits
    i11m0010 00 10 2    S-8      1 8 bits
    i11m0100 01 00 4    V2-32    2 32 bits
    i11m0101 01 01 5    V2-16    2 16 bits
    i11m0110 01 10 6    V2-8     2 8 bits
    i11m1000 10 00 8    V3-32    3 32 bits
    i11m1001 10 01 9    V3-16    3 16 bits
    i11m1010 10 10 A    V3-8     3 8 bits
    i11m1100 11 00 C    V4-32    4 32 bits
    i11m1101 11 01 D    V4-16    4 16 bits
    i11m1110 11 10 E    V4-8     4 8 bits
    i11m1111 11 11 F    V4-5     4 5+5+5+1 bits
    
'''
pack_type = {
    # type         format   signed / unsigned
    'int'       :   ('i',   0),
    'uint'      :   ('I',   1),
    'short'     :   ('h',   0),
    'ushort'    :   ('H',   1),
    'byte'      :   ('b',   0),
    'ubyte'     :   ('B',   1),
    'float'     :   ('f',   0)
}
class EncodePS2VIFUnpack():
    '''encode/pack ps2 vif unpack'''
    def __init__(self, number, addr, unpack_format, data_type, input_data):
        self.addr = addr
        self.unsignd = pack_type[data_type][1]
        self.flag = 1
        self.number = number
        self.format = unpack_format
        self.vl = unpack_format & 0x3
        self.vn = (unpack_format >> 2) & 0x3
        self.numElems = self.vn + 1
        self.elemBits = 0
        if self.vl == 0:
            self.elemBits = 32
        elif self.vl == 1:
            self.elemBits = 16
        elif self.vl == 2:
            self.elemBits = 8
        elif self.vl == 3:      # Format 0xF
            self.elemBits = 5   # 5+5+5+1 bits
        self.m = 0
        self.command = 3
        self.interrupt = 0
        self.padding_Length = 0
        self.dataSize = 0
        if self.number:
            self.dataSize = self.number * self.numElems * (self.elemBits // 8)
            if self.format == 0xF:
                self.dataSize = self.number * 2
            if self.dataSize % 4:
                self.padding_Length = 4 - (self.dataSize % 4)
        # self.data = None
        self.data_type = pack_type[data_type][0]
        self.input_data = input_data
        self.buffer = None
    def encode(self):
        vif_unpack = int((self.addr & 0xFFFF) | self.unsignd << 14 | self.flag << 15)
        vif_unpack |= int(self.number & 0xff) << 16
        vif_unpack |= int(self.vl | self.vn << 2 | self.m << 4 | self.command << 5 |\
                    self.interrupt << 7) << 24
        return vif_unpack
    def write(self):
        buffer = bytes()
        for i in range(self.number):
            formatstr = self.numElems * self.data_type
            if self.numElems > 1:
                temp_data = list(self.input_data[i])
                buffer += struct.pack(formatstr, *temp_data)
            else:
                buffer += struct.pack(formatstr, self.input_data[i])
        for p in range(self.padding_Length):
            buffer += pack('b',0)
        self.buffer = buffer
        return buffer
def flat_matrix4x3(mat:Matrix):
    return (mat[0][0],mat[0][1],mat[0][2],
            mat[1][0],mat[1][1],mat[1][2],
            mat[2][0],mat[2][1],mat[2][2],
            mat[3][0],mat[3][1],mat[3][2],
            )
def get_geometry_list_texture_names(geometry_list):
    texture_names = []
    for geo in geometry_list:
        for mat in geo.material_list:
            if mat.rw.has_texture:
                tex_name = None
                for x in mat.node_tree.nodes:
                    if x.type=='TEX_IMAGE':
                        tex_name = x.image.name
                if tex_name is None:
                    tex_name = mat.rw.texture_name
                if tex_name not in texture_names:
                    texture_names.append(tex_name)
    return texture_names
def find_skin_mesh_armatures(mesh_list):
    armatures = []
    for mesh_obj in mesh_list:
        arm_mod = None
        for mod in mesh_obj.modifiers:
            if mod.type == 'ARMATURE':
                arm_mod = mod
                break
        if arm_mod is not None:
            cur_arm_obj = arm_mod.object
            if cur_arm_obj is not None:
                armatures.append(cur_arm_obj)
    if armatures:
        return armatures
    return None
RW_Chunks = {
    'Struct'            : 0x1,
    'String'            : 0x2,
    'Extension'         : 0x3,
    'Texture'           : 0x6,
    'Material'          : 0x7,
    'Material List'     : 0x8,
    'Frame List'        : 0xE,
    'Geometry'          : 0xF,
    'Clump'             : 0x10,
    'Atomic'            : 0x14,
    'Geometry List'     : 0x1A,
    'Right to Render'   : 0x1F,
    'Sky Mipmap Val'    : 0x110,
    'Skin PLG'          : 0x116,
    'HAnim PLG'         : 0x11E,
    'Bin Mesh PLG'      : 0x50E,
    'RpAtomic Mksobj Plugin'        : 0x895302,
    'RpMaterial MkMaterial Plugin'  : 0x895303,
}

class RWChunk:
    ''' RW chunk header'''
    def __init__(self, chunk_id, rw_libaray_id, data_size = 0):
        self.chunk_id = chunk_id
        self.data_size = data_size
        self.rw_libaray_id = rw_libaray_id

    def to_bytes(self):
        '''get output buffer'''
        return pack('<3I',self.chunk_id, self.data_size, self.rw_libaray_id)



def pack_rw_libaray_id(version, build):
    '''pack rw libaray id'''
    if version <= 0x31000:
        return version >> 8
    libaray_id = (version - 0x30000) << 14 | (version & 0x3F) << 16 | (build & 0xFFFF)
    return libaray_id

def unpack_rw_version(libaray_id):
    '''unpack rw libaray version'''
    if libaray_id & 0xFFFF0000:
        return (libaray_id >> 14 & 0x3FF00) + 0x30000 | (libaray_id & 0x3f)
    return libaray_id << 8

def unpack_rw_build(libaray_id):
    if libaray_id & 0xFFFF0000:
        return libaray_id & 0xFFFF
    return 0

def get_padding_length(offset, align_length):
    return int(((offset + (align_length-1)) & -align_length) - offset)


class Geometry(object):

    def __init__(self, mesh_obj):
        self.meshobj : bpy.types.Object = mesh_obj
        self.armature_obj = None
        self.vertices = None
        self.normals = None
        self.uv1s = None
        self.uv2s = None
        self.colors = None
        self.boneids = None
        self.weights = None
        self.faces = None
        self.face_matid_list = None
        self.matrix:Matrix = None
        self.num_uv = None
        self.has_colors = False
        self.has_skin = False
        self.face_groups = None
        self.face_group_split_matids = None
        self.tristrip_groups = None
        self.face_indices_count = 0
        self.material_list = None
        self.vertex_groups_names = None
        self.tristrip_global = None
        self.bone_index_map = None
        self.bone_name_map = None
        self.mk_boneids = None
        self.max_weights_per_vertex = 0
        self.num_used_bones = 0
        self.used_bones = None
        self.bone_palettes_split_by_material = None
        self.loops_faces = None
        self.loops_colors = None
        self.loops_normals = None
        self.loops_vertices = None
        self.loops_uv1s = None
        self.loops_uv2s = None
        self.loops_vertex_boneids = None
        self.loops_vertex_weights = None
    def get_mesh_data(self):
        meshobj = self.meshobj
        # meshobj.rotation_euler = (-1.570796,0,0)
        # triangulateMod = meshobj.modifiers.new("Triangulate",type='TRIANGULATE')
        # triangulateMod.keep_custom_normals = True
        mesh = bpy.data.meshes.new_from_object(meshobj,preserve_all_data_layers=True)
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.triangulate(bm, faces=bm.faces)
        bm.to_mesh(mesh)
        bm.free()
        # object_matrix = meshobj.matrix_world.transposed()
        obj_rot_matrix = Euler((-1.570796,0,0)).to_matrix().to_4x4()
        object_matrix = meshobj.matrix_world @ obj_rot_matrix
        object_matrix = object_matrix.transposed()
        # print("object matrix",object_matrix)
        # print("self matrix ", meshobj.matrix_world)
        face_matid_list = []
        matid_list = []
        for face in mesh.polygons:
            mat_id = face.material_index
            face_matid_list.append(mat_id)
            if mat_id not in matid_list:
                matid_list.append(mat_id)
        matid_list.sort()
        matid_count = len(matid_list)
        self.face_group_split_matids = matid_list
        self.face_matid_list = face_matid_list
        GlobalFaces = []
        for f in mesh.polygons:
            GlobalFaces.append(tuple(f.vertices))

        mesh.calc_normals_split() # very important
        #mesh.calc_tangents()
        flat_normals = np.empty(len(mesh.loops) * 3,  dtype=np.single)
        mesh.loops.foreach_get("normal", flat_normals)
        mesh.free_normals_split()

        loops_normals = []
        temp_normals = flat_normals.reshape(-1,3).tolist()
        rot_matrix = object_matrix.inverted().to_3x3().inverted().transposed()
        for n in temp_normals:
            normal = Vector((n[0],n[1],n[2]))
            normal = rot_matrix @ normal
            normal.normalize()
            loops_normals.append(tuple(normal))


        loops_faces = []
        loops_vertices = []
        transform_matrix = object_matrix.inverted()
        for i,f in enumerate(GlobalFaces):
            loops_faces.append((i*3, i*3+1, i*3+2))
            for v in f:
                vertex = mesh.vertices[v].co
                vertex = transform_matrix @ vertex
                loops_vertices.append(tuple(vertex))

        num_uv = len(mesh.uv_layers)

        if num_uv:
            flat_uv1s = np.empty(len(mesh.loops) * 2,  dtype=np.single)
            mesh.uv_layers[0].data.foreach_get('uv', flat_uv1s)
            loops_uv1s = flat_uv1s.reshape(-1,2).tolist()
            if num_uv > 1:
                num_uv = 2
                flat_uv2s = np.empty(len(mesh.loops) * 2,  dtype=np.single)
                mesh.uv_layers[1].data.foreach_get('uv', flat_uv2s)
                loops_uv2s = flat_uv2s.reshape(-1,2).tolist()

        has_colors = len(mesh.vertex_colors)
        if has_colors:
            flat_colors = np.empty(len(mesh.loops) * 4,  dtype=np.single)
            mesh.vertex_colors[0].data.foreach_get('color', flat_colors)
            temp_loops_colors = flat_colors.reshape(-1,4).tolist()
            loops_colors = []
            for col in temp_loops_colors:
                loops_colors.append((int(col[0]*255),int(col[1]*255),int(col[2]*255),int(col[3]*255)))
        # has_skin = len(meshobj.vertex_groups)
        has_skin = False
        for mod in meshobj.modifiers:
            if mod.type == 'ARMATURE':
                has_skin = True
        # print("have skin:",has_skin)
        if has_skin:
            numVert = len(mesh.vertices)
            vertex_weights = [[]] * numVert
            vertex_boneids = [[]] * numVert

            vertex_groups_names = []
            for vgs in meshobj.vertex_groups:
                vertex_groups_names.append(vgs.name)
                #print(vgs.index)
            # https://b3d.interplanety.org/en/getting-vertex-weights-by-vertex-groups/
            # for group in meshobj.vertex_groups:
            #    group_index = group.index
            #    vert_in_group = [vert for vert in meshobj.data.vertices \
            #        if group_index in [i.group for i in vert.groups]]
            #    vg = [[group.group for group in vert.groups] for vert in vert_in_group]
            #    gr = [v.groups[[g.group for g in v.groups].index(group_index)].weight \
            #     for v in vert_in_group]
            for vert in mesh.vertices:
                #print(vert.index,len(vert.groups))
                boneids = [group.group for group in vert.groups ]
                weights = [group.weight for group in vert.groups]
                vertex_boneids[vert.index] = boneids
                vertex_weights[vert.index] = weights

            loops_vertex_weights = [[]] * len(mesh.loops)
            loops_vertex_boneids = [[]] * len(mesh.loops)
            for i,f in enumerate(GlobalFaces):
                for vi,v in enumerate(f):
                    loops_vertex_boneids[i * 3 + vi] = vertex_boneids[v]
                    loops_vertex_weights[i * 3 + vi] = vertex_weights[v]
                    #print(len(vertex_boneids[v]))
            self.vertex_groups_names = vertex_groups_names
            # print(vertex_groups_names)
            # print("weights count:",len(loops_vertex_weights))
            # print("boneids count:",len(loops_vertex_boneids))
            #print(loops_vertex_boneids)
            #print(loops_vertex_weights)
        self.loops_faces = loops_faces
        if has_colors:
            self.loops_colors = loops_colors
        self.loops_normals = loops_normals
        self.loops_vertices = loops_vertices
        if num_uv:
            self.loops_uv1s = loops_uv1s
            if num_uv > 1:
                self.loops_uv2s = loops_uv2s
        if has_skin:
            self.loops_vertex_boneids = loops_vertex_boneids
            self.loops_vertex_weights = loops_vertex_weights
        self.num_uv = num_uv
        self.has_colors = has_colors
        self.has_skin = has_skin
        # meshobj.modifiers.remove(triangulateMod)
        '''
        face_gruops = []
        for mat_id in matid_list:
            temp_faces = []
            for i,face in enumerate(loops_faces):
                if face_matid_list[i] == mat_id:
                    temp_faces.append(tuple(face))
            face_gruops.append(temp_faces)
        num_loops = len(mesh.loops)
        unique_vertex_elements_strings = []
        unique_vertex_elements_indices = []
        loops_vertex_elements_strings = []
        for i in range(num_loops):
            vertex_element_str = ""
            vx,vy,vz = loops_vertices[i]
            vertex_str = '%f,%f,%f' % (vx, vy, vz)
            # nx,ny,nz = loops_normals[i]
            # normal_str = '%f,%f,%f' % (nx, ny, nz)
            vertex_element_str += vertex_str # + "," + normal_str

            if num_uv:
                u1,v1 = loops_uv1s[i]
                uv_str = "%f,%f" % (u1,v1)
                vertex_element_str += "," + uv_str
                if num_uv > 1:
                    u2,v2 = loops_uv2s[i]
                    uv2_str = "%f,%f" % (u2,v2)
                    vertex_element_str += "," + uv2_str
            if has_colors:
                r,g,b,a = loops_colors[i]
                col_str = "%i,%i,%i,%i" % (r,g,b,a)
                vertex_element_str += "," + col_str
            if has_skin:
                skin_str = ""
                for bi in loops_vertex_boneids[i]:
                    skin_str += "," + ('%i' % bi)
                for w in loops_vertex_weights[i]:
                    skin_str += "," + ('%f' % w)
                vertex_element_str += skin_str
            if vertex_element_str not in unique_vertex_elements_strings:
                unique_vertex_elements_strings.append(vertex_element_str)
                unique_vertex_elements_indices.append(i)
            loops_vertex_elements_strings.append(vertex_element_str)
            # print(i,vertex_element_str)
        # print("unique elements count:",len(unique_vertex_elements_strings))
        num_unique_vertex = len(unique_vertex_elements_strings)
        vertices = []
        normals = []
        uv1s = []
        uv2s = []
        colors = []
        boneids = []
        weights = []
        for i in unique_vertex_elements_indices:
            vertices.append(loops_vertices[i])
            normals.append(loops_normals[i])
            if num_uv:
                uv1s.append(loops_uv1s[i])
                if num_uv > 1:
                    uv2s.append(loops_uv2s[i])
            if has_colors:
                colors.append(loops_colors[i])
            if has_skin:
                boneids.append(loops_vertex_boneids[i])
                weights.append(loops_vertex_weights[i])
        faces = []
        for f in loops_faces:
            temp = []
            for v in f:
                unique_vertex_str = loops_vertex_elements_strings[v]
                unique_vertex_index = unique_vertex_elements_strings.index(unique_vertex_str)
                temp.append(unique_vertex_index)
            faces.append(tuple(temp))
        face_gruops = []
        for mat_id in matid_list:
            temp_faces = []
            for i,face in enumerate(faces):
                if face_matid_list[i] == mat_id:
                    temp_faces.append(tuple(face))
            face_gruops.append(temp_faces)
        

        flat_faces = []
        for sublist in faces:
            flat_faces.extend(sublist)
        '''
        del mesh

        self.unique_face_groups_vertex_element()

        # start_time = time.time() # 记录开始时间
        # 这里放置需要计时的代码段

        # Thanks https://github.com/HENDRIX-ZT2/jpog-blender/blob/master/utils/trianglestripifier.py
        strip_global = stripify(self.faces, stitchstrips = True)[0]
        self.tristrip_global = strip_global


        # end_time = time.time()   # 记录结束时间
        # execution_time = end_time - start_time # 计算运行时间
        # ("nv strip time:", execution_time)
        
        tristrip_groups = []
        strip_index_count = 0
        for faces in self.face_groups:
            strip = stripify(faces, stitchstrips = True)[0]
            tristrip_groups.append(strip)
            strip_index_count += len(strip)

        self.face_indices_count = strip_index_count
        self.tristrip_groups = tristrip_groups

        '''
        self.faces = faces
        self.face_groups = face_gruops
        self.vertices = vertices
        self.normals = normals
        if num_uv:
            self.uv1s = uv1s
            if num_uv > 1:
                self.uv2s = uv2s
        if has_colors:
            self.colors = colors
        if has_skin:
            self.boneids = boneids
            self.weights = weights
        '''
        # self.matrix = meshobj.matrix_world.transposed()
        # meshobj.rotation_euler = (1.570796,0,0)
        self.matrix = object_matrix

        arm_mod = None
        for mod in meshobj.modifiers:
            if mod.type == 'ARMATURE':
                arm_mod = mod
                break
        if arm_mod is not None and arm_mod.object is not None:
            self.armature_obj = arm_mod.object

    def unique_face_groups_vertex_element(self):
        temp_face_gruops = []
        for mat_id in self.face_group_split_matids:
            temp_faces = []
            for i,face in enumerate(self.loops_faces):
                if self.face_matid_list[i] == mat_id:
                    temp_faces.append(tuple(face))
            temp_face_gruops.append(temp_faces)
        face_start_index = 0
        for faces,mat_id in zip(temp_face_gruops, self.face_group_split_matids):
            for i in range(len(faces)):
                self.face_matid_list[i + face_start_index] = mat_id
            face_start_index += len(faces)
        vertices = []
        normals = []
        uv1s = []
        uv2s = []
        colors = []
        boneids = []
        weights = []
        faces = []
        face_groups = []
        start_index = 0
        for sub_faces in temp_face_gruops:
            cur_group_vertices = []
            cur_group_normals = []
            cur_group_colors = []
            cur_group_uv1s = []
            cur_group_uv2s = []
            cur_group_boneids = []
            cur_group_weights = []
            cur_group_faces = []
            for i,face in enumerate(sub_faces):
                cur_group_faces.append((i*3, i*3+1, i*3+2))
                for v in face:
                    cur_group_vertices.append(self.loops_vertices[v])
                    cur_group_normals.append(self.loops_normals[v])
                    if self.has_colors:
                        cur_group_colors.append(self.loops_colors[v])
                    if self.num_uv:
                        cur_group_uv1s.append(self.loops_uv1s[v])
                        if self.num_uv > 1:
                            cur_group_uv2s.append(self.loops_uv2s[v])
                    if self.has_skin:
                        cur_group_boneids.append(self.loops_vertex_boneids[v])
                        cur_group_weights.append(self.loops_vertex_weights[v])
            num_loops = len(cur_group_vertices)
            unique_vertex_elements_strings = []
            unique_vertex_elements_indices = []
            loops_vertex_elements_strings = []
            for i in range(num_loops):
                vertex_element_str = ""
                vx,vy,vz = cur_group_vertices[i]
                vertex_str = '%f,%f,%f' % (vx, vy, vz)
                # nx,ny,nz = loops_normals[i]
                # normal_str = '%f,%f,%f' % (nx, ny, nz)
                vertex_element_str += vertex_str # + "," + normal_str

                if self.num_uv:
                    u1,v1 = cur_group_uv1s[i]
                    uv_str = "%f,%f" % (u1,v1)
                    vertex_element_str += "," + uv_str
                    if self.num_uv > 1:
                        u2,v2 = cur_group_uv2s[i]
                        uv2_str = "%f,%f" % (u2,v2)
                        vertex_element_str += "," + uv2_str
                if self.has_colors:
                    r,g,b,a = cur_group_colors[i]
                    col_str = "%i,%i,%i,%i" % (r,g,b,a)
                    vertex_element_str += "," + col_str
                if self.has_skin:
                    skin_str = ""
                    for bi in cur_group_boneids[i]:
                        skin_str += "," + ('%i' % bi)
                    for w in cur_group_weights[i]:
                        skin_str += "," + ('%f' % w)
                    vertex_element_str += skin_str
                if vertex_element_str not in unique_vertex_elements_strings:
                    unique_vertex_elements_strings.append(vertex_element_str)
                    unique_vertex_elements_indices.append(i)
                loops_vertex_elements_strings.append(vertex_element_str)
            num_unique_vertex = len(unique_vertex_elements_strings)
            cur_vertices = []
            cur_normals = []
            cur_uv1s = []
            cur_uv2s = []
            cur_colors = []
            cur_boneids = []
            cur_weights = []
            for i in unique_vertex_elements_indices:
                cur_vertices.append(cur_group_vertices[i])
                vertices.append(cur_group_vertices[i])
                cur_normals.append(cur_group_normals[i])
                normals.append(cur_group_normals[i])
                if self.num_uv:
                    cur_uv1s.append(cur_group_uv1s[i])
                    uv1s.append(cur_group_uv1s[i])
                    if self.num_uv > 1:
                        cur_uv2s.append(cur_group_uv2s[i])
                        uv2s.append(cur_group_uv2s[i])
                if self.has_colors:
                    cur_colors.append(cur_group_colors[i])
                    colors.append(cur_group_colors[i])
                if self.has_skin:
                    cur_boneids.append(cur_group_boneids[i])
                    cur_weights.append(cur_group_weights[i])
                    boneids.append(cur_group_boneids[i])
                    weights.append(cur_group_weights[i])
            cur_faces = []
            temp_faces = []
            for f in cur_group_faces:
                temp = []
                for v in f:
                    unique_vertex_str = loops_vertex_elements_strings[v]
                    unique_vertex_index = unique_vertex_elements_strings.index(unique_vertex_str)
                    temp.append(unique_vertex_index)
                cur_faces.append(tuple(temp))
                temp_faces.append((temp[0]+start_index,temp[1]+start_index,temp[2]+start_index))
                faces.append((temp[0]+start_index,temp[1]+start_index,temp[2]+start_index))

            face_groups.append(temp_faces)
            start_index += len(cur_vertices)
        self.faces = faces
        self.vertices = vertices
        self.normals = normals
        if self.num_uv:
            self.uv1s = uv1s
            if self.num_uv > 1:
                self.uv2s = uv2s
        if self.has_colors:
            self.colors = colors
        if self.has_skin:
            self.boneids = boneids
            self.weights = weights
        self.face_groups = face_groups
    def get_material_list(self):
        self.material_list = []
        for mat_slot in self.meshobj.material_slots:
            if mat_slot.material:
                self.material_list.append(mat_slot.material)
                #if mat_slot.material.node_tree:
                #print("material:" + str(mat_slot.material.name))
                #for x in mat_slot.material.node_tree.nodes:
                #        if x.type=='TEX_IMAGE':
                #        print(" texture: "+str(x.image.name))

        # print(self.material_list)

    def update_bone_map(self, hanim_bone_names:list):
        bone_index_map = []
        bone_name_map = []
        for vertex_group_name in self.vertex_groups_names:
            index = hanim_bone_names.index(vertex_group_name)
            bone_index_map.append(index)
            bone_name_map.append(hanim_bone_names[index])
        self.bone_index_map = bone_index_map
        self.bone_name_map = bone_name_map
        temp_boneids = []
        if self.has_skin:
            for boneids in self.boneids:
                temp = []
                # print(boneids)
                for boneid in boneids:
                    update_id = bone_index_map[boneid]
                    temp.append(update_id)
                temp_boneids.append(temp)
        self.mk_boneids = temp_boneids
        # print(self.mk_boneids)
    def get_skin_plugin_info(self):
        max_weights_per_vertex = 0
        global_used_bones = []
        for faces in self.face_groups:
            for face in faces:
                for v in face:
                    boneids = self.mk_boneids[v]
                    for index in boneids:
                        if index not in global_used_bones:
                            global_used_bones.append(index)
                    if len(boneids) > max_weights_per_vertex:
                        max_weights_per_vertex = len(boneids)
        num_used_bones = len(global_used_bones)
        self.max_weights_per_vertex = max_weights_per_vertex
        self.num_used_bones = num_used_bones
        self.used_bones = global_used_bones
    def get_bone_palette_split_by_material(self):
        num_split = len(self.face_group_split_matids)
        bone_palettes_split_by_material = []
        max_weights_per_vertex = 0
        global_used_bones = []

        # get bone palette
        for faces in self.face_groups:
            used_boneids = []
            for face in faces:
                for v in face:
                    boneids = self.mk_boneids[v]
                    for index in boneids:
                        if index not in used_boneids:
                            used_boneids.append(index)
                        if index not in global_used_bones:
                            global_used_bones.append(index)
                    if len(boneids) > max_weights_per_vertex:
                        max_weights_per_vertex = len(boneids)
            # used_boneids.sort()
            bone_palettes_split_by_material.append(used_boneids)
        # print(bone_palettes_split_by_material)
        num_used_bones = len(global_used_bones)

        # remap boneid
        #changed_vertices = []
        mk_boneids = self.mk_boneids.copy()
        for i,faces in enumerate(self.face_groups):
            bone_palette = bone_palettes_split_by_material[i]
            for face in faces:
                for v in face:
                    #if v not in changed_vertices:
                    boneids = self.mk_boneids[v]
                    temp = []
                    for index in boneids:
                        #if index not in bone_palette:
                        #    print("bone id not range")
                        remap_index = bone_palette.index(index)
                        temp.append(remap_index)
                    mk_boneids[v] = temp
                    #changed_vertices.append(v)
                    # print(boneids,temp)
        self.mk_boneids = mk_boneids
        self.boneids = mk_boneids
        self.bone_palettes_split_by_material = bone_palettes_split_by_material
        self.max_weights_per_vertex = max_weights_per_vertex
        self.num_used_bones = num_used_bones
        self.used_bones = global_used_bones
    def test_rebulid_mesh(self):
        vertices = []
        for v in self.vertices:
            transform_v = self.matrix.transposed() @ Vector(v)
            vertices.append(transform_v)
            # print(v,transform_v)
        normals = []
        rot_matrix = self.matrix.transposed().to_3x3().inverted().transposed()
        for n in self.normals:
            n = rot_matrix @ Vector(n)
            n.normalize()
            normals.append(n)
        strip_faces = convert_tristrip_to_trianglelist(self.tristrip_global)
        mesh = bpy.data.meshes.new("Mesh")
        obj = bpy.data.objects.new("Mesh",mesh)
        bpy.context.scene.collection.objects.link(obj)
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        mesh.from_pydata(vertices,[],strip_faces)
        # mesh.normals_split_custom_set(loops_normals)
        # mesh.normals_split_custom_set(flat_normals.reshape(-1,3))
        mesh.normals_split_custom_set_from_vertices(normals)
        mesh.use_auto_smooth = True
        mesh.uv_layers.new(do_init=False)
        mesh.uv_layers[-1].data.foreach_set('uv', [
            vt for uv in [self.uv1s[loop.vertex_index] for loop in mesh.loops]
            for vt in uv])

        #obj.matrix_world = self.matrix
        # mesh.transform(self.matrix)
        # print(self.matrix)
        # print(obj.matrix_world)
        mesh.update()

        if self.has_skin:
            for i,(boneids,weights) in enumerate(zip(self.boneids, self.weights)):
                for boneid,weight in zip(boneids,weights):
                    if weight != 0:
                        groupName = self.vertex_groups_names[boneid]
                        if groupName not in obj.vertex_groups:
                            obj.vertex_groups.new(name = groupName)
                        obj.vertex_groups[groupName].add([i],weight,'ADD')
        # Skin
        if self.armature_obj and self.has_skin:
            armatureMod = obj.modifiers.new("Armature","ARMATURE")
            armatureMod.object = self.armature_obj
        # obj.matrix_world = self.matrix
        obj.rotation_euler = (1.570796,0,0)
        # mesh.transform(Euler((1.570796,0,0)).to_matrix().to_4x4())

class Frame(object):

    def __init__(self):
        self.bone = self
        self.index = None
        self.parent = None
        self.parent_index = -1
        self.childrens = None
        self.name = None
        self.matrix_local : Matrix = None
        self.matrix_world : Matrix = None
        self.boneID = None
        self.boneIndex = None
        self.groupID = None
        self.boneType = None
        self.copy_bones = None
        self.copy_infos = None
        self.hanim_list_id = None
    def copy(self):
        frame = Frame()
        frame.index = self.index
        frame.parent = self.parent
        frame.parent_index = self.parent_index
        frame.childrens = self.childrens
        frame.name = self.name
        frame.matrix_local = self.matrix_local
        frame.matrix_world = self.matrix_world
        frame.boneID = self.boneID
        frame.boneIndex = self.boneIndex
        frame.groupID = self.groupID
        frame.boneType = self.boneType
        frame.copy_bones = self.copy_bones
        frame.copy_infos = self.copy_infos
        frame.hanim_list_id = self.hanim_list_id
        return frame
MKBones = {
    # Full ID   Group   CopyID  ID      Bone type
    0x99000:    (0x9,   0x9000, 0x1000, 2),
    0x99002:    (0x9,   0x9002, 0x1002, 2),
    0x89002:    (0x8,   0x9002, 0x1002, 0),
    0x89005:    (0x8,   0x9005, 0x1005, 2),
    0x79005:    (0x7,   0x9005, 0x1005, 0),
    0x79008:    (0x7,   0x9008, 0x1008, 0),
    0xC9000:    (0xC,   0x9000, 0x1000, 2),
    0xC9001:    (0xC,   0x9001, 0x1001, 2),
    0xB9001:    (0xB,   0x9001, 0x1001, 0),
    0xB9004:    (0xB,   0x9004, 0x1004, 2),
    0xA9004:    (0xA,   0x9004, 0x1004, 0),
    0xA9007:    (0xA,   0x9007, 0x1007, 0),
    0xE9000:    (0xE,   0x9000, 0x1000, 2),
    0xE9003:    (0xE,   0x9003, 0x1003, 0),
    0x0900D:    (0x0,   0x900D, 0x100D, 2),
    0x09010:    (0x0,   0x9010, 0x1010, 0),
    0x3900E:    (0x3,   0x900E, 0x100E, 2),
    0x39011:    (0x3,   0x9011, 0x1011, 0),
    0x19017:    (0x1,   0x9017, 0x1017, 0),
    0x19019:    (0x1,   0x9019, 0x1019, 0),
    0x6900C:    (0x6,   0x900C, 0x100C, 0),
    0x6900F:    (0x6,   0x900F, 0x100F, 0),
    0x59012:    (0x5,   0x9012, 0x1012, 0),
    0x59014:    (0x5,   0x9014, 0x1014, 0),
    0x49016:    (0x4,   0x9016, 0x1016, 0),
    0x49018:    (0x4,   0x9018, 0x1018, 0),
}
class FrameList(object):

    def __init__(self, armature_obj) -> None:
        self.armature:bpy.types.Armature =  armature_obj.data
        self.armature_obj:bpy.types.Object =  armature_obj
        # self.root_rotation_matrix = Euler((-1.570796,0,0)).to_matrix().to_4x4() # rotate x -90
        self.skin_bone_list = None
        self.hierarchical_list = None
        self.hanim_bone_list = None
        self.hanim_bone_names = None
        self.hierarchical_names = None
    def get_frame_list(self):
        arm = self.armature
        bone_parents = []
        bone_childrens = []
        bone_names = []
        temp_frame_list = []
        '''
        view_layer = bpy.context.view_layer
        obj_active = view_layer.objects.active
        selection = bpy.context.selected_objects
        bpy.ops.object.select_all(action='DESELECT')
        self.armature_obj.select_set(True)
        #self.armature_obj.rotation_euler = (-1.570796,0,0)
        #bpy.ops.object.posemode_toggle()
        bpy.ops.object.mode_set(mode='POSE', toggle=False)
        for i,bone in enumerate(self.armature_obj.pose.bones):
            bone_names.append(bone.name)
            frame = Frame()
            frame.name = bone.name
            frame.matrix_local = bone.matrix.transposed()
            frame.matrix_world = bone.matrix.transposed()
            if bone.parent is not None:
                frame.matrix_local = bone.parent.matrix.inverted() @ bone.matrix
                frame.matrix_local = frame.matrix_local.transposed()
            frame.index = i
            temp_frame_list.append(frame)
            #print(frame.name)
            #print("matrix world:",frame.matrix_world)
            #print("matrix local:",frame.matrix_local)
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        #self.armature_obj.rotation_euler = (1.570796,0,0)
        for frame in temp_frame_list:
            for bone in arm.bones:
                if bone.name == frame.name:
                    frame.boneID = bone.get('boneID')
                    frame.boneIndex = bone.get('boneIndex')
                    frame.groupID = bone.get('groupID')
                    frame.boneType = bone.get('boneType')
                    frame.hanim_list_id = bone.get('hanim_list_id')
                    frame.copy_bones = bone.get('copy_bones')
                    if frame.copy_bones:
                        frame.copy_infos = []
                        for j in range(frame.copy_bones):
                            keystr = "copy_" + str(j)
                            frame.copy_infos.append(bone.get(keystr))
                    break
        view_layer.objects.active = obj_active
        for obj in selection:
            obj.select_set(True)

        '''
        self.armature_obj.rotation_euler = (-1.570796,0,0)
        for i,bone in enumerate(arm.bones):
            bone_names.append(bone.name)
            frame = Frame()
            frame.name = bone.name
            frame.matrix_local = bone.matrix_local.transposed()
            frame.matrix_world = bone.matrix_local.transposed()
            if bone.parent is not None:
                frame.matrix_local = bone.parent.matrix_local.inverted() @ bone.matrix_local
                frame.matrix_local = frame.matrix_local.transposed()
            frame.boneID = bone.get('boneID')
            frame.boneIndex = bone.get('boneIndex')
            frame.groupID = bone.get('groupID')
            frame.boneType = bone.get('boneType')
            frame.index = i
            frame.hanim_list_id = bone.get('hanim_list_id')
            frame.copy_bones = bone.get('copy_bones')
            if frame.copy_bones:
                frame.copy_infos = []
                for j in range(frame.copy_bones):
                    keystr = "copy_" + str(j)
                    frame.copy_infos.append(bone.get(keystr))
            temp_frame_list.append(frame)
        self.armature_obj.rotation_euler = (1.570796,0,0)

        for i,bone in enumerate(arm.bones):
            # print(i,bone.name)
            for parent_index,pbone in enumerate(arm.bones):
                if bone.parent == pbone:
                    temp_frame_list[i].parent = temp_frame_list[parent_index]
                    temp_frame_list[i].parent_index = parent_index
                    break
            temp = []
            temp_childrens = []
            for child_index, sbone in enumerate(arm.bones):
                if sbone.parent is not None:
                    if sbone.parent == bone:
                        temp.append(sbone)
                        temp_childrens.append(temp_frame_list[child_index])
            temp_frame_list[i].childrens = temp_childrens
            bone_childrens.append(temp)
            bone_parents.append(bone.parent)

        # print("method 1")
        parent_children_list = []
        root_frame = temp_frame_list[0]
        get_parent_children_frame_list(root_frame, parent_children_list)
        #for i,frame in enumerate(parent_children_list):
        #    print(i,frame.name,frame.parent_index,frame.boneID,frame.boneIndex)
        #    parent_children_list[i].boneIndex = i
        self.skin_bone_list = parent_children_list
        #group_id_list = []
        # for i,frame in enumerate(parent_children_list):
        #    if frame.groupID is not None and frame.groupID not in group_id_list:
        #        group_id_list.append(frame.groupID)
        group_id_list = [13,9,8,7,12,11,10,14,15,3,2,1,6,5,4,0]
        hanim_bone_list = []
        hanim_bone_names = []
        for group_id in group_id_list:
            for i,frame in enumerate(parent_children_list):
                hanim_frame =  frame.copy()
                cur_group_id = frame.groupID
                if cur_group_id  is not None and cur_group_id == group_id and \
                    hanim_frame not in hanim_bone_list:
                    hanim_bone_list.append(hanim_frame)
                    hanim_bone_names.append(hanim_frame.name)

        for frame in hanim_bone_list.copy():
            if frame.copy_bones:
                for j in range(frame.copy_bones):
                    info = frame.copy_infos[j]
                    group_id = info & 0xf
                    skin_index = (info >> 8) & 0xffff
                    bone_type = info >> 24
                    copy_frame = frame.copy()
                    copy_frame.groupID = group_id
                    copy_frame.boneIndex = skin_index
                    copy_frame.boneType = bone_type
                    copy_frame.boneID = copy_frame.boneID | 0x8000
                    copy_frame.hanim_list_id = (info >> 16) & 0xff
                    copy_frame.name = "copy_"+str(skin_index)+"_"+\
                        str(copy_frame.boneID) + "_" + str(group_id) \
                        + "_" + copy_frame.name
                    hanim_bone_list.append(copy_frame)
                    hanim_bone_names.append(copy_frame.name)
        temp_list = []
        temp_name_list = []
        for index in range(len(hanim_bone_list)):
            for i,frame in enumerate(hanim_bone_list):
                hanim_list_id = frame.hanim_list_id
                if hanim_list_id == index:
                    temp_list.append(frame)
                    temp_name_list.append(frame.name)
                    break
        # self.hanim_bone_list = hanim_bone_list
        # self.hanim_bone_names = hanim_bone_names
        self.hanim_bone_list = temp_list
        self.hanim_bone_names = temp_name_list
        #for i,frame in enumerate(hanim_bone_list):
        #    print(i,frame.name,frame.parent_index,frame.boneID,frame.boneIndex)
        # print("method 2")s
        parent_children_list2 = []
        get_hierarchical_list(root_frame, parent_children_list2)
        #for i,frame in enumerate(parent_children_list2):
        #    print(i,frame.matrix_local,frame.matrix_world)
            #print(i,frame.name,frame.parent_index,frame.boneID,frame.boneIndex)
        self.hierarchical_list = parent_children_list2
        self.hierarchical_names = [frame.name for frame in self.hierarchical_list]
    def test_rebulid_skeleton(self):
        # build skeleton
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        armature_data = bpy.data.armatures.new('armature_data')
        armature_obj = bpy.data.objects.new('armature_obj_test', armature_data)

        bpy.context.scene.collection.objects.link(armature_obj)
        bpy.context.view_layer.objects.active = armature_obj
        # armature_data.display_type = 'STICK'
        armature_obj.show_in_front = True
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        bones = []
        #for frame in self.skin_bone_list:
        for frame in self.hierarchical_list:
            bone:bpy.types.EditBone = armature_obj.data.edit_bones.new(frame.name)
            armature_obj.data.edit_bones.active = bone
            bone.head = [0, 0, 0]
            bone.tail = Vector([0, 0.05, 0])
            bone.show_wire = True
            bone['boneID'] = frame.boneID
            bone['boneIndex'] = frame.boneIndex
            bone['groupID'] = frame.groupID
            bone['boneType'] = frame.boneType
            if frame.parent_index > -1:
                bone.matrix = frame.matrix_local.transposed()
                bone.parent = bones[frame.parent_index]
                bone.matrix = bone.matrix @ bone.parent.matrix
            else:
                bone.matrix = frame.matrix_world
            bones.append(bone)
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        armature_obj.rotation_euler = (1.570796,0,0)
def get_parent_children_frame_list(frame:Frame, parent_children_list:list, parent_index = -1):
    '''顺序：先找其中一个子，然后再找子的子，循环完再找另一个子，以及另一个子的子'''
    copy_frame = frame.copy()
    if frame.parent is not None:
        copy_frame.parent_index = parent_index
        copy_frame.parent = parent_children_list[parent_index]
        copy_frame.childrens = None
    copy_frame.index = len(parent_children_list)
    parent_children_list.append(copy_frame)
    for child_frame in frame.childrens:
        get_parent_children_frame_list(child_frame, parent_children_list, copy_frame.index)

def get_hierarchical_list(frame:Frame, parent_children_list:list):
    '''顺序：先找到所有的子，然后再找子的子'''
    copy_frame = frame.copy()
    if frame.parent is None:
        copy_frame.index = len(parent_children_list)
        parent_children_list.append(copy_frame)
    # get all sub bone
    copy_frame.childrens = []
    for child_frame in frame.childrens:
        sub_frame = child_frame.copy()
        sub_frame.parent_index = copy_frame.index
        sub_frame.parent = parent_children_list[sub_frame.parent_index]
        sub_frame.index = len(parent_children_list)
        copy_frame.childrens.append(sub_frame)
        parent_children_list.append(sub_frame)
    # get sub's sub bone
    for child_frame in copy_frame.childrens:
        get_hierarchical_list(child_frame, parent_children_list)


def get_scene_collection():

    view_layer = bpy.context.view_layer
    obj_active = view_layer.objects.active
    selection = bpy.context.selected_objects
    bpy.ops.object.select_all(action='DESELECT')

    armature_collection = []
    meshobj_collection = []
    for obj in selection:
        obj.select_set(True)
        view_layer.objects.active = obj
        if obj.type == "MESH":
            meshobj_collection.append(obj)
        elif obj.type == "ARMATURE":
            armature_collection.append(obj)
        obj.select_set(False)
    collection = {}
    collection['meshs'] = meshobj_collection
    collection['armatures'] = armature_collection

    view_layer.objects.active = obj_active
    for obj in selection:
        obj.select_set(True)

    return collection

def convert_tristrip_to_trianglelist(stripList):
    faces = []
    for i,vi in enumerate(stripList):
        if i > 1:
            f1 = stripList[i-2]
            f2 = stripList[i-1]
            f3 = vi
            if f1 != f2 and f2 != f3 and f1 != f3:
                if i % 2 == 0:
                    faces.append((f1, f2, f3))
                else:
                    faces.append((f2, f1, f3))
    return faces
