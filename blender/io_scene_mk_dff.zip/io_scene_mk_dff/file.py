import struct


SEEK_SET = 0
SEEK_CUR = 1
SEEK_END = 2


class BinaryStream:
    """ Binary Stream reader and writer"""

    def __init__(self, data=None, endianType="LitteEndian"):
        self.data = data
        if data is None:
            self.data = bytes()
        else:
            self.dataSize = len(data)
        self.setEndian(endianType)
        self.offset = 0
        self.f = self

    def getSize(self):
        return len(self.data)

    def getBuffer(self):
        return self.data

    def checkEOF(self):
        return self.tell() >= self.getSize()

    def setEndian(self, endianType):
        if endianType == "LitteEndian":
            self.endian = "<"
        elif endianType == "BigEndian":
            self.endian = ">"

    def read(self, numBytes=0):
        if numBytes:
            outBytes = self.data[self.offset:self.offset + numBytes]
            self.offset += numBytes
            return outBytes
        else:
            outBytes = self.data
            self.offset = self.dataSize
            return outBytes

    def tell(self):
        return self.f.offset

    def seek(self, offset, seekType=SEEK_SET):
        if seekType == SEEK_SET:
            self.offset = offset
        elif seekType == SEEK_CUR:
            self.offset += offset
        elif seekType == SEEK_END:
            self.offset = self.dataSize - offset

    def readBytes(self, numBytes):
        return self.f.read(numBytes)

    def readByte(self):
        return struct.unpack(self.endian + "b", self.f.read(1))[0]

    def readUByte(self):
        return struct.unpack(self.endian + "B", self.f.read(1))[0]

    def readShort(self):
        return struct.unpack(self.endian + "h", self.f.read(2))[0]

    def readUShort(self):
        return struct.unpack(self.endian + "H", self.f.read(2))[0]

    def readInt(self):
        return struct.unpack(self.endian + "i", self.f.read(4))[0]

    def readUInt(self):
        return struct.unpack(self.endian + "I", self.f.read(4))[0]

    def readInt64(self):
        return struct.unpack(self.endian + "q", self.f.read(8))[0]

    def readUInt64(self):
        return struct.unpack(self.endian + "Q", self.f.read(8))[0]

    def readFloat(self):
        return struct.unpack(self.endian + "f", self.f.read(4))[0]

    def readDouble(self):
        return struct.unpack(self.endian + "d", self.f.read(8))[0]

    def readString(self):
        outStr = ""
        startOffset = self.offset
        while self.data[self.offset] != 0:
            self.offset += 1
        if startOffset != self.offset:
            outStr = str(self.data[startOffset:self.offset], "ASCII") \
                .rstrip("\0")
        else:
            self.offset += 1
        return outStr

    def readFixedLengthString(self, length):
        outStr = ""
        strBytes = self.data[self.offset:self.offset + length]
        self.offset += length
        startOffset = 0
        curOffset = 0
        while strBytes[curOffset] != 0:
            curOffset += 1
        if startOffset != curOffset:
            outStr = str(strBytes[startOffset:curOffset], "ASCII").rstrip("\0")
        return outStr

    def write(self, data: bytes):

        endOffset = self.offset + len(data)
        if self.offset >= self.getSize():
            self.data += data
            self.offset += len(data)
        else:
            if endOffset < self.getSize():
                tempByteArray = bytearray(self.data)
                tempByteArray[self.offset:self.offset + len(data)] = data
                self.offset += len(data)
                self.data = bytes(tempByteArray)
            else:
                tempByteArray = bytearray(self.data)
                overWriteBytesLen = self.getSize() - self.offset
                tempByteArray[self.offset:self.offset + overWriteBytesLen] = \
                    data[0:overWriteBytesLen]
                self.data = bytes(tempByteArray)
                newBytesLen = len(data) - overWriteBytesLen
                self.data += data[overWriteBytesLen:newBytesLen]
                self.offset += len(data)
        self.dataSize = self.getSize()

    def writeBytes(self, data):
        self.f.write(data)

    def writeByte(self, val):
        self.write(struct.pack(self.endian + "b", val))

    def writeUByte(self, val):
        self.write(struct.pack(self.endian + "B", val))

    def writeShort(self, val):
        self.write(struct.pack(self.endian + "h", val))

    def writeUShort(self, val):
        self.write(struct.pack(self.endian + "H", val))

    def writeInt(self, val):
        self.write(struct.pack(self.endian + "i", val))

    def writeUInt(self, val):
        self.write(struct.pack(self.endian + "I", val))

    def writeInt64(self, val):
        self.write(struct.pack(self.endian + "q", val))

    def writeUInt64(self, val):
        self.write(struct.pack(self.endian + "Q", val))

    def writeFloat(self, val):
        self.write(struct.pack(self.endian + "f", val))

    def writeDouble(self, val):
        self.write(struct.pack(self.endian + "d", val))


class BinaryReader:
    def __init__(self, f, endianType="LitteEndian"):
        self.f = f

        self.setEndian(endianType)
        curOffset = f.tell()
        f.seek(0, SEEK_END)
        self.fileSize = f.tell()
        f.seek(curOffset, SEEK_SET)

    def setEndian(self, endianType):
        if endianType == "LitteEndian":
            self.endian = "<"
        elif endianType == "BigEndian":
            self.endian = ">"

    def tell(self):
        return self.f.tell()

    def seek(self, offset, seekType=SEEK_SET):
        if seekType == SEEK_SET:
            self.f.seek(offset)
        elif seekType == SEEK_CUR:
            self.f.seek(offset, seekType)
        elif seekType == SEEK_END:
            self.f.seek(offset, seekType)

    def readBytes(self, numBytes):
        return self.f.read(numBytes)

    def readByte(self):
        return struct.unpack(self.endian + "b", self.f.read(1))[0]

    def readUByte(self):
        return struct.unpack(self.endian + "B", self.f.read(1))[0]

    def readShort(self):
        return struct.unpack(self.endian + "h", self.f.read(2))[0]

    def readUShort(self):
        return struct.unpack(self.endian + "H", self.f.read(2))[0]

    def readInt(self):
        return struct.unpack(self.endian + "i", self.f.read(4))[0]

    def readUInt(self):
        return struct.unpack(self.endian + "I", self.f.read(4))[0]

    def readInt64(self):
        return struct.unpack(self.endian + "q", self.f.read(8))[0]

    def readUInt64(self):
        return struct.unpack(self.endian + "Q", self.f.read(8))[0]

    def readFloat(self):
        return struct.unpack(self.endian + "f", self.f.read(4))[0]

    def readDouble(self):
        return struct.unpack(self.endian + "d", self.f.read(8))[0]
