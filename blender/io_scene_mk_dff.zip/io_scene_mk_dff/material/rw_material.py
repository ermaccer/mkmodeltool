import bpy
import os

class RW_Material_Panel(bpy.types.Panel):
    """Creates a Panel in the material context of the properties editor"""
    bl_label = "Renderware Material"
    bl_idname = "MATERIAL_PT_RW_layout"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "material"

    def draw(self, context):
        layout = self.layout
        blmat = context.material
        if context.material is not None:
            mat = context.material.rw
            layout.label(text="Surface Properties:")
            row = layout.row()
            row.prop(mat, "ambient")
            row = layout.row()
            row.prop(mat, "specular")
            row = layout.row()
            row.prop(mat, "diffuse")
            row = layout.row()
            row.prop(mat, "has_texture",text="Has Texture")
            if mat.has_texture:

                #tex_node = None
                #for x in blmat.node_tree.nodes:
                    # print(x.type)
                   # if x.type=='TEX_IMAGE':
                        #tex_node = x
                        #print(" texture: "+str(x.image.name))
                        #tex_name = os.path.splitext(x.image.name)[0]
                        #break
                row = layout.row()
                row.prop(mat, "texture_name",text="Textrue Name")
                layout.label(text="Texture Properties:")
                box = layout.box()
                box.prop(mat, "texture_filter")
                box = layout.box()
                box.prop(mat, "u_addressing")
                box = layout.box()
                box.prop(mat, "v_addressing")
                row = layout.row()
                row.prop(mat, "has_skymipmap",text="Has Skymipmap")
                if mat.has_skymipmap:
                    layout.label(text=" PS2 SkyMipmapVal:")
                    row = layout.row()
                    row.prop(mat, "PS2_SkyMipmapVal_K",text="K")
                    # row = layout.row()
                    row.prop(mat, "PS2_SkyMipmapVal_L",text="L")
class RW_Material_Props(bpy.types.PropertyGroup):

    ambient : bpy.props.FloatProperty("ambient",default=1.0,max=1.0,min=0.0)
    specular : bpy.props.FloatProperty("specular",default=1.0,max=1.0,min=0.0)
    diffuse : bpy.props.FloatProperty("diffuse",default=1.0,max=1.0,min=0.0)
    has_texture : bpy.props.BoolProperty("Has Texture",default=True)
    texture_name : bpy.props.StringProperty("Texture Name",default="empty_image",
        description="This takes effect only when the BDSF node has no input image. "+
        "By default, the image name is searched from the BSDF node. "+
        "If no image name is found, the texture name is read from this property.")
    texture_filter : bpy.props.EnumProperty(
        name="Filter",
        description="Texture Filter Mode Flags",
        items=(
            ('0', "FILTERNAFILTERMODE", "filtering is disabled"),
            ('1', "FILTERNEAREST", "Point sampled"),
            ('2', "FILTERLINEAR", "Bilinear"),
            ('3', "FILTERMIPNEAREST", "Point sampled per pixel mip map"),
            ('4', "FILTERMIPLINEAR", "Bilinear per pixel mipmap"),
            ('5', "FILTERLINEARMIPNEAREST", "MipMap interp point sampled"),
            ('6', "FILTERLINEARMIPLINEAR", "Trilinear"),
        ),
        default='2',
    )
    u_addressing : bpy.props.EnumProperty(
        name="U addressing",
        description="Texture addressing modes",
        items=(
            ('0', "TEXTUREADDRESSNATEXTUREADDRESS", "no tiling"),
            ('1', "TEXTUREADDRESSWRAP", "tile in U or V direction"),
            ('2', "TEXTUREADDRESSMIRROR", "mirror in U or V direction"),
            ('3', "TEXTUREADDRESSCLAMP", ""),
            ('4', "TEXTUREADDRESSBORDER", ""),
            ('5', "Unknown5", ""),
            ('6', "Unknown6", ""),
            ('7', "Unknown7", ""),
            ('8', "Unknown8", ""),
            ('9', "Unknown9", ""),
        ),
        default='2',
    )
    v_addressing : bpy.props.EnumProperty(
        name="V addressing",
        description="Texture addressing modes",
        items=(
            ('0', "TEXTUREADDRESSNATEXTUREADDRESS", "no tiling"),
            ('1', "TEXTUREADDRESSWRAP", "tile in U or V direction"),
            ('2', "TEXTUREADDRESSMIRROR", "mirror in U or V direction"),
            ('3', "TEXTUREADDRESSCLAMP", ""),
            ('4', "TEXTUREADDRESSBORDER", ""),
            ('5', "Unknown5", ""),
            ('6', "Unknown6", ""),
            ('7', "Unknown7", ""),
            ('8', "Unknown8", ""),
            ('9', "Unknown9", ""),
        ),
        default='2',
    )
    has_skymipmap : bpy.props.BoolProperty(default=True)
    PS2_SkyMipmapVal_K : bpy.props.IntProperty("K",min=-2048,max=2047)
    PS2_SkyMipmapVal_L : bpy.props.IntProperty("L",min=0,max=3)

    def register():
        bpy.types.Material.rw = bpy.props.PointerProperty(type=RW_Material_Props)


class MK_Material_Props(bpy.types.PropertyGroup):
    type : bpy.props.IntProperty("type",default=5,min=0,max=5)
    uv_scroll : bpy.props.BoolProperty("uv scroll",default=False)
    unk1 : bpy.props.IntProperty(min=0,max=65535)
    unk2 : bpy.props.IntProperty(min=0,max=65535)
    unk3 : bpy.props.FloatProperty()
    spec_r : bpy.props.IntProperty(default=127,min=0,max=255)
    spec_g : bpy.props.IntProperty(default=127,min=0,max=255)
    spec_b : bpy.props.IntProperty(default=127,min=0,max=255)
    spec_a : bpy.props.IntProperty(default=255,min=0,max=255)
    unk5 : bpy.props.FloatProperty()
    unk6 : bpy.props.FloatProperty()
    uv_scroll_speed_x : bpy.props.FloatProperty()
    uv_scroll_speed_y : bpy.props.FloatProperty()
    uv_scroll_speed_z : bpy.props.FloatProperty()

    def register():
        bpy.types.Material.mk = bpy.props.PointerProperty(type=MK_Material_Props)

class MK_Material_Panel(bpy.types.Panel):
    """Creates a Panel in the material context of the properties editor"""
    bl_label = "Mortal Kombat Extension"
    bl_idname = "MATERIAL_PT_MK_layout"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "material"

    def draw(self, context):
        layout = self.layout
        blmat = context.material
        if context.material is not None:
            mat = context.material.mk
            row = layout.row()
            row.prop(mat, "type")
            row = layout.row()
            row.prop(mat, "unk1",text="unk1 short")
            row = layout.row()
            row.prop(mat, "unk2",text="unk2 short")
            row = layout.row()
            row.prop(mat, "unk3",text="unk3 float")
            if mat.type >= 3:
                layout.label(text="Specular color:")
                row = layout.row()
                row.prop(mat, "spec_r",text="R")
                #row = layout.row()
                row.prop(mat, "spec_g",text="G")
                row = layout.row()
                row.prop(mat, "spec_b",text="B")
                #row = layout.row()
                row.prop(mat, "spec_a",text="A")
            if mat.type >= 4:
                row = layout.row()
                row.prop(mat, "unk5",text="unk5 float")
                row = layout.row()
                row.prop(mat, "unk6",text="unk6 float")
                row = layout.row()
                row.prop(mat, "uv_scroll",text="Has UV Scroll")
                if mat.uv_scroll:
                    layout.label(text="UV scroll xyz speed:")
                    row = layout.row()
                    row.prop(mat, "uv_scroll_speed_x")
                    row = layout.row()
                    row.prop(mat, "uv_scroll_speed_y")
                    row = layout.row()
                    row.prop(mat, "uv_scroll_speed_z")
