import bpy
import os
import io
import struct
import bmesh
from mathutils import Vector, Matrix
from .file import *

def LibraryIdUnpackRWVersion(libid):
    if libid & 0xFFFF0000:
        return (libid >> 14 & 0x3FF00) + 0x30000 | (libid >> 16 & 0x3F)
    return libid << 8


class RWChunk:
    def __init__(self, bs):
        self.chunkID, self.chunkSize, self.chunkVersion = struct.unpack("3I", bs.readBytes(12))
        self.version = LibraryIdUnpackRWVersion(self.chunkVersion)


class Clump:
    def __init__(self, bs: BinaryStream):
        self.bs = bs
        self.mdlList = []

    def ReadClump(self):
        clumpStructHeader = ReadClumpStruct(self.bs)
        frameListHeader = RWChunk(self.bs)
        nextOfs = self.bs.tell() + frameListHeader.chunkSize

        frameList = FrameList(self.bs)
        frame_armature_obj = frameList.ReadBoneList()
        armature_obj = frameList.get_mk_bones()
        self.bs.seek(nextOfs)

        geometryListHeader = RWChunk(self.bs)
        geometryListStructHeader = RWChunk(self.bs)
        geometryCount = self.bs.readUInt()
        geoListOfs = self.bs.tell()
        if geometryCount:
            self.bs.seek(geometryListHeader.chunkSize - 16, SEEK_CUR)

        # 获取模型的父骨的矩阵，用于变换顶点，顶点需要乘上父级矩阵
        vertexTransformMatrixList = [0] * clumpStructHeader.numAtomics
        if clumpStructHeader.numAtomics:
            atomicData = bytes()
            for i in range(clumpStructHeader.numAtomics):
                atomicHeader = RWChunk(self.bs)
                atomicData += self.bs.readBytes(atomicHeader.chunkSize)
            atomicList = rAtomicList(atomicData, clumpStructHeader.numAtomics).rAtomicStruct()
            for j in range(clumpStructHeader.numAtomics):
                vertexTransformMatrixList[atomicList[j].geometryIndex] \
                    = frameList.frameMatrixList[atomicList[j].frameIndex]
        endOfs = self.bs.tell()
        self.bs.seek(geoListOfs)
        if geometryCount:
            geometryList = rGeometryList(
                self.bs, geometryCount,
                vertexTransformMatrixList,
                frameList.hAnimBoneMap,
                armature_obj,
                frameList.vertexGroupNames, frameList, atomicList)
            geometryList.readGeometry()
        self.bs.seek(endOfs)
        

class ReadClumpStruct:
    def __init__(self, bs):
        self.chunkID, self.chunkSize, self.chunkVersion = struct.unpack("3I", bs.readBytes(12))
        self.numAtomics = bs.readUInt()
        self.version = LibraryIdUnpackRWVersion(self.chunkVersion)
        if self.version >= 0x33000:
            self.numLights = bs.readUInt()
            self.numCameras = bs.readUInt()


GlobalBoneNames = {
    '4096': "Bip01",
    '4097': "Bip01_L_Thigh",
    '4100': "Bip01_L_Calf",
    '4103': "Bip01_L_Foot",
    '4106': "Bip01_L_Toe0",
    '4098': "Bip01_R_Thigh",
    '4101': "Bip01_R_Calf",
    '4104': "Bip01_R_Foot",
    '4107': "Bip01_R_Toe0",
    '4099': "Bip01_Spine",
    '4102': "Bip01_Spine1",
    '4105': "Bip01_Spine2",

    '4110': "Bip01_R_Clavicle",
    '4113': "Bip01_R_UpperArm",
    '4115': "Bip01_R_UpperArm2",
    '4117': "Bip01_R_Forearm",
    '4119': "Bip01_R_Forearm2",
    '4121': "Bip01_R_Hand",
    '4131': "Bip01_R_Finger1",
    '4141': "Bip01_R_Finger11",
    '4151': "Bip01_R_Finger111",
    '4127': "Bip01_R_Finger2",
    '4137': "Bip01_R_Finger22",
    '4123': "Bip01_R_Finger3",
    '4133': "Bip01_R_Finger33",
    '4125': "Bip01_R_Finger4",
    '4135': "Bip01_R_Finger44",
    '4129': "Bip01_R_Finger5",
    '4139': "Bip01_R_Finger55",

    '4108': "Bip01_L_Clavicle",
    '4111': "Bip01_L_UpperArm",
    '4114': "Bip01_L_UpperArm2",
    '4116': "Bip01_L_Forearm",
    '4118': "Bip01_L_Forearm2",
    '4120': "Bip01_L_Hand",
    '4130': "Bip01_L_Finger1",
    '4140': "Bip01_L_Finger11",
    '4150': "Bip01_L_Finger111",    
    '4126': "Bip01_L_Finger2",
    '4136': "Bip01_L_Finger22",    
    '4122': "Bip01_L_Finger3",
    '4132': "Bip01_L_Finger33",
    '4124': "Bip01_L_Finger4",
    '4134': "Bip01_L_Finger44",
    '4128': "Bip01_L_Finger5",
    '4138': "Bip01_L_Finger55",
 
    '4109': "Bip01_Neck",
    '4112': "Bip01_Head",

}


def GetMatrix(datas):
    m = struct.unpack('<12f', datas)
    mat = Matrix((
        (m[0], m[1], m[2], 0),
        (m[3], m[4], m[5], 0),
        (m[6], m[7], m[8], 0),
        (m[9], m[10], m[11], 1)))
    return mat.transposed()
def GetMatrix4x4(datas):
    m = struct.unpack('<16f', datas)
    mat = Matrix((
        (m[0], m[1], m[2], m[3]),
        (m[4], m[5], m[6], m[7] ),
        (m[8], m[9], m[10], m[11] ),
        (m[12], m[13], m[14], m[15])))
    return mat.transposed()

class FrameList(object):
    def __init__(self, bs):
        self.bs = bs
        # self.bs = bs
        self.frameCount = 0
        self.boneMatList = []
        self.bonePrtIdList = []
        self.boneIndexList = []
        self.animBoneIDList = []
        self.boneNameList = []
        self.hAnimBoneIDList = []
        self.hSkinBoneIDList = []       # boneMap1 包含重复骨头，没有实体的骨头
        self.hAnimBoneMap = []          # boneMap2 不包含没有实体的骨头
        self.hSkinBoneMapNames = []
        self.hAnimBoneTypeList = []
        self.hanim_bone_count = 0
        self.bones = []
        self.skinBones = []
        self.hasHAnim = False
        self.boneInfoList = []
        self.armature_obj = None
        self.frameMatrixList = []
        self.hAnimFrameMatrixList = []
        self.FrameListStruct()
        self.ReadFrameExtList()
        self.vertexGroupNames = None
    def FrameListStruct(self):
        header = RWChunk(self.bs)
        frameCount = self.bs.readUInt()
        self.frameCount = frameCount
        if frameCount:
            for i in range(frameCount):
                boneMat = GetMatrix(self.bs.readBytes(48))
                bonePrtId = self.bs.readInt()
                self.bs.readInt()
                self.boneMatList.append(boneMat)
                self.bonePrtIdList.append(bonePrtId)
                self.boneIndexList.append(i)

                skinBne = SkinBone()
                skinBne.boneName = "bone" + str(i)
                skinBne.listID = i
                skinBne.listParentID = bonePrtId
                skinBne.matrix = boneMat
                skinBne.animBoneID = -1
                skinBne.skinBoneID = -1
                skinBne.skinBoneParentID = -1
                self.boneInfoList.append(skinBne)

    def ReadHAnimPLG(self, index):
        hAnimVersion = self.bs.readInt()
        animBoneID = self.bs.readInt()
        self.animBoneIDList.append(animBoneID)
        self.boneInfoList[index].animBoneID = animBoneID
        boneCount = self.bs.readUInt()
        if boneCount:
            self.hanim_bone_count = boneCount
            self.hasHAnim = True
            flags = self.bs.readInt()
            keyFrameSize = self.bs.readInt()
            for i in range(boneCount):
                self.hAnimBoneIDList.append(self.bs.readUInt())
                self.hSkinBoneIDList.append(self.bs.readInt())
                boneType = self.bs.readInt()
                self.hAnimBoneTypeList.append(boneType)

    def ReadFrameExt(self, index):
        header = RWChunk(self.bs)
        endOfs = self.bs.tell() + header.chunkSize
        if header.chunkSize:
            while self.bs.tell() < endOfs:
                chunk = RWChunk(self.bs)
                if chunk.chunkID == 0x11e:
                    self.ReadHAnimPLG(index)
                else:
                    self.bs.seek(chunk.chunkSize, 1)
        else:   # if no animation bone indent add empty info
            self.animBoneIDList.append(-1)
        if index == 0:
            self.boneNameList.append("Root")
        else:
            self.boneNameList.append("Bone" + str(index))
        self.boneInfoList[index].boneName = self.boneNameList[index]

    def ReadFrameExtList(self):
        for i in range(self.frameCount):
            self.ReadFrameExt(i)

    def ReadBoneList(self):

        # collection = bpy.data.collections.new("DFF Collection")
        # bpy.context.scene.collection.children.link(collection)
        # collection.objects.link(armature_obj)
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        armature_data = bpy.data.armatures.new('armature_data')
        armature_obj = bpy.data.objects.new('armature_obj', armature_data)

        bpy.context.scene.collection.objects.link(armature_obj)

        bpy.context.view_layer.objects.active = armature_obj

        armature_data.display_type = 'STICK'
        armature_obj.show_in_front = True
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        # bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'

        # Just list order
        bones = []
        for i in range(self.frameCount):
            boneIndex = i
            boneName = self.boneNameList[i]
            boneMat = self.boneMatList[i]
            bonePIndex = self.bonePrtIdList[i]
            bone = armature_obj.data.edit_bones.new(boneName)
            armature_obj.data.edit_bones.active = bone
            bone.head = [0, 0, 0]
            bone.tail = Vector([0, 0.05, 0])
            # Bone位置以head的位置为准
            matrix = boneMat
            bone.matrix = matrix

            if bonePIndex > -1:
                bone.parent = bones[bonePIndex]
                self.frameMatrixList.append(bone.matrix @ bone.parent.matrix)
                bone.matrix = bone.matrix @ bone.parent.matrix
            else:
                self.frameMatrixList.append(bone.matrix)
                # print(bone.matrix)
            bones.append(bone)

        self.bones = bones
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        # return bones
        armature_obj.rotation_euler = (1.570796,0,0)
        self.armature_obj = armature_obj
        return armature_obj

    def find_copy_bones(self, anim_bone_id):
        # self.hAnimBoneIDList
        # self.hSkinBoneIDList
        # self.hAnimBoneTypeList
        copy_bones = []
        for i,bone_id in enumerate(self.hAnimBoneIDList):
            if bone_id & 0x8000:
                if bone_id & 0x7fff == anim_bone_id:
                    group_id = bone_id >> 16 & 0xf
                    skin_index = self.hSkinBoneIDList[i]
                    bone_type = self.hAnimBoneTypeList[i]
                    hanim_list_id = i
                    info = group_id | (skin_index & 0xff) << 8  | \
                        hanim_list_id << 16 |  bone_type << 24
                    copy_bones.append(info)
        return copy_bones
    def set_copy_bones_property(self, bone, copy_bones):
        if copy_bones:
            bone['copy_bones'] = len(copy_bones)
            for i,info in enumerate(copy_bones):
                strkey = "copy_" + str(i)
                bone[strkey] = info
        else:
            bone['copy_bones'] = 0
    def get_mk_bones(self):
        if self.hasHAnim:
            self.armature_obj.select_set(True)
            bpy.ops.object.delete(use_global=False, confirm=False)

            skinBoneInfoList = list.copy(self.boneInfoList)
            # just find source bone list skin bone index
            # 利用AnimBoneID补全对应的SkinBoneID
            for i in range(self.frameCount):
                animBoneID = self.boneInfoList[i].animBoneID
                for j in range(len(self.hSkinBoneIDList)):
                    hAnimBoneID = self.hAnimBoneIDList[j] & 0xffff
                    SkinBoneID = self.hSkinBoneIDList[j]
                    if hAnimBoneID == animBoneID:
                        self.boneInfoList[i].skinBoneID = SkinBoneID
                        break

            # 利用AnimBoneID 复制骨骼信息
            for i,SkinBoneID in enumerate(self.hSkinBoneIDList):
                # hAnimBoneID = self.hAnimBoneIDList[i] & 0x7fff   # 不包含重复骨头
                hAnimBoneID = self.hAnimBoneIDList[i] & 0xffff     # 包含重复骨头

                # 该循环数量为实际骨头数量，不包含重复骨头

                for j in range(self.frameCount):
                    animBoneID = self.boneInfoList[j].animBoneID
                    sknBne = self.boneInfoList[j]

                    if hAnimBoneID == animBoneID:
                        bname = ""
                        if GlobalBoneNames.get(str(hAnimBoneID)):
                            bname = "_" + GlobalBoneNames[str(hAnimBoneID)]
                        newSknBone = SkinBone()
                        newSknBone.skinBoneID = SkinBoneID
                        newSknBone.listParentID = sknBne.listParentID
                        newSknBone.matrix = sknBne.matrix
                        newSknBone.animBoneID = hAnimBoneID
                        newSknBone.listID = sknBne.listID
                        newSknBone.groupID = self.hAnimBoneIDList[i] >> 16
                        newSknBone.boneType = self.hAnimBoneTypeList[i]
                        newSknBone.boneName = "Bone" \
                            + str(SkinBoneID) + "_" + str(hAnimBoneID) + "_" + \
                            str(newSknBone.groupID) + bname
                        newSknBone.hanim_list_id = i
                        skinBoneInfoList[sknBne.listID] = newSknBone

                        # 不包含重复骨头的骨头映射表
                        self.hAnimBoneMap.append(self.boneInfoList[j].skinBoneID)

                        # 添加非重复骨头名称 不包含重复骨头的对应HAnim列表的骨头名称映射表
                        self.hSkinBoneMapNames.append(newSknBone.boneName)
                        break
                    if (hAnimBoneID & 0x8000) and (hAnimBoneID & 0x7fff) == animBoneID:
                        bname = ""
                        if GlobalBoneNames.get(str(hAnimBoneID & 0x7fff)):
                            bname = "_" + GlobalBoneNames[str(hAnimBoneID & 0x7fff)]
                        boneName = "Bone" \
                            + str(SkinBoneID) + "_" + str(hAnimBoneID & 0x7fff) + "_" +\
                            str(self.hAnimBoneIDList[i] >> 16) + bname
                        # 添加重复骨头对应实际的名称
                        # 不包含重复骨头的对应HAnim列表的骨头名称映射表
                        self.hSkinBoneMapNames.append(boneName)

                        # 添加重复骨头对应实际的蒙皮索引 不包含重复骨头的骨头映射表
                        self.hAnimBoneMap.append(self.boneInfoList[j].skinBoneID)
                        break

            # 检查未被蒙皮使用的骨头，并填充，例如根骨和第二根骨头
            # 还有HAinm skin bone index会出现中间索引缺少，不连续现象。
            unusedBoneCount = 0
            startSkinIndex = 0
            for i in range(self.frameCount):
                sknBne = skinBoneInfoList[i]
                if sknBne.animBoneID == -1:
                    skinBoneInfoList[i] = self.boneInfoList[i]
                    unusedBoneCount += 1
            if unusedBoneCount:
                startSkinIndex = unusedBoneCount - 1

            vertexGroupNames = []
            for j in range(self.hanim_bone_count):
                boneID = self.hAnimBoneIDList[j] & 0x7fff
                for skin_bone in skinBoneInfoList:
                    cur_boneID = skin_bone.animBoneID
                    if cur_boneID == boneID:
                        vertexGroupNames.append(skin_bone.boneName)
                        break
            self.vertexGroupNames = vertexGroupNames

            # build skeleton
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            armature_data = bpy.data.armatures.new('armature_data')
            armature_obj = bpy.data.objects.new('armature_obj', armature_data)
            bpy.context.scene.collection.objects.link(armature_obj)
            bpy.context.view_layer.objects.active = armature_obj
            # armature_data.display_type = 'STICK'
            armature_obj.show_in_front = True
            bpy.ops.object.mode_set(mode='EDIT', toggle=False)

            skinBones = []
            for j in range(self.frameCount):
                sknBne = skinBoneInfoList[j]
                boneID = skinBoneInfoList[j].animBoneID
                boneIndex = skinBoneInfoList[j].skinBoneID
                boneName = skinBoneInfoList[j].boneName
                matrix = skinBoneInfoList[j].matrix
                groupID = skinBoneInfoList[j].groupID
                boneType = skinBoneInfoList[j].boneType
                bonePIndex = skinBoneInfoList[j].listParentID - unusedBoneCount
                hanim_list_id = skinBoneInfoList[j].hanim_list_id
                # 创建骨头
                if bonePIndex >= -1:
                    bone = armature_obj.data.edit_bones.new(boneName)
                    armature_obj.data.edit_bones.active = bone
                    bone.head = [0, 0, 0]
                    bone.tail = Vector([0, 0.05, 0])
                    bone.show_wire = True
                    bone['boneID'] = boneID
                    bone['boneIndex'] = boneIndex
                    bone['groupID'] = groupID
                    bone['boneType'] = boneType
                    bone['hanim_list_id'] = hanim_list_id
                    copy_bones = self.find_copy_bones(boneID)
                    self.set_copy_bones_property(bone, copy_bones)
                    bone.matrix = matrix
                    if bonePIndex > -1:
                        bone.parent = skinBones[bonePIndex]
                        self.hAnimFrameMatrixList.append(
                            bone.matrix @ bone.parent.matrix)
                        bone.matrix = bone.matrix @ bone.parent.matrix
                    skinBones.append(bone)
            bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
            armature_obj.rotation_euler = (1.570796,0,0)
            self.skinBones = skinBones
            self.armature_obj = armature_obj
            return armature_obj
        return self.armature_obj

class SkinBone(object):
    def __init__(self):
        self.boneName = None
        self.matrix = None
        self.skinBoneID = -1
        self.animBoneID = -1
        self.skinBoneParentID = -1
        self.listID = -1
        self.listParentID = -1
        self.groupID = None
        self.boneType = None
        self.hanim_list_id = None

class rGeometryList(object):
    def __init__(self, bs: BinaryStream,geometryCount, vertMatList, \
                hSkinBoneIDList,armature_obj, vertexGroupNames, \
                frame_list, atomic_list):
        self.bs = bs
        self.geometryCount = geometryCount
        self.vertMatList = vertMatList
        self.matList = []
        self.hSkinBoneIDList = hSkinBoneIDList
        self.armature_obj = armature_obj
        self.vertexGroupNames = vertexGroupNames
        self.frame_list = frame_list
        self.atomic_list = atomic_list

    def readGeometry(self):
        for i in range(self.geometryCount):
            # print("GEOID:",i)
            vertMat = self.vertMatList[i]
            geometryHeader = RWChunk(self.bs)
            # datas = self.bs.readBytes(geometryHeader.chunkSize)
            # geo = rGeomtry(datas,vertMat,self.hSkinBoneIDList)
            geo = rGeomtry(self.bs, vertMat, self.hSkinBoneIDList, self.armature_obj,\
                           self.vertexGroupNames, i, self.frame_list, self.atomic_list)
            geo.rGeometryStruct()
            for m in range(len(geo.matList)):
                self.matList.append(geo.matList[m])


class rMatrial(object):
    def __init__(self, datas, mat_index):
        self.bs = BinaryStream(datas)
        # self.bs =  bs
        self.MKMaterialSkinBonePalette = []
        self.diffuseColor = None
        self.useBonePalette = False
        self.meshTypeFlag = None
        self.hasTexture = False
        self.mat_index = mat_index
        self.material = None
    def rMaterialStruct(self):
        global InputName
        header = RWChunk(self.bs)
        unused = self.bs.readInt()
        colorR = self.bs.readUByte()
        colorG = self.bs.readUByte()
        colorB = self.bs.readUByte()
        colorA = self.bs.readUByte()
        self.diffuseColor = [colorR, colorG, colorB, colorA]
        unused2 = self.bs.readInt()
        hasTexture = self.bs.readInt()
        ambient = self.bs.readFloat()
        specular = self.bs.readFloat()
        diffuse = self.bs.readFloat()
        self.hasTexture = hasTexture
        texName = ""
        has_skymipmap = False
        if hasTexture:
            texHeader = RWChunk(self.bs)
            texStructHeader = RWChunk(self.bs)
            textureFilter = self.bs.readUByte()
            UVAddressing = self.bs.readUByte()
            useMipLevelFlag = self.bs.readUShort()
            # nameBytes = self.bs.readBytes(RWChunk(self.bs).chunkSize)
            texName = self.bs.readFixedLengthString(RWChunk(self.bs).chunkSize)

            self.bs.seek(RWChunk(self.bs).chunkSize, 1)
            texExtHeader = RWChunk(self.bs)
            #self.bs.seek(texExtHeader.chunkSize, 1)
            if texExtHeader.chunkSize:
                end_offset = self.bs.tell() + texExtHeader.chunkSize
                hdr = RWChunk(self.bs)
                if hdr.chunkID == 0x110:
                    has_skymipmap = True
                    ps2_skymipmap_val = self.bs.readInt()
                    K = ps2_skymipmap_val & 0xfff
                    L = (ps2_skymipmap_val >> 12) & 3
                self.bs.seek(end_offset)

        # Create Material
        matName = "mtl" + str(self.mat_index)
        if texName != "":
            matName = texName
        blMaterial = bpy.data.materials.get(matName)
        if blMaterial is None:
            blMaterial = bpy.data.materials.new(name=matName)
            blMaterial.use_nodes = True
            blMaterial.rw.ambient = ambient
            blMaterial.rw.specular = specular
            blMaterial.rw.diffuse = diffuse
            blMaterial.rw.has_texture = hasTexture
            blMaterial.rw.texture_name = texName
            if hasTexture:
                blMaterial.rw.texture_filter = str(textureFilter)
                blMaterial.rw.u_addressing = str(UVAddressing >> 4)
                blMaterial.rw.v_addressing = str(UVAddressing & 0xf)
                if has_skymipmap:
                    blMaterial.rw.has_skymipmap = True
                    blMaterial.rw.PS2_SkyMipmapVal_K = K
                    blMaterial.rw.PS2_SkyMipmapVal_L = L
                path = os.path.dirname(InputName)

                for ext in [".bmp",".tga"]:
                    texFileName = os.path.join(path,texName+ext)
                    if os.path.exists(texFileName):
                        image = bpy.data.images.load(texFileName)
                        for node in blMaterial.node_tree.nodes:
                            #if node.name in ["Principled BSDF","原理化BSDF"]:
                            if node.type == 'BSDF_PRINCIPLED':
                                bsdf = node
                                break
                        tex_node = blMaterial.node_tree.nodes.new(type="ShaderNodeTexImage")
                        tex_node.image = image
                        blMaterial.node_tree.links.new(tex_node.outputs['Color'],
                                                        bsdf.inputs['Base Color'])
                        #blMaterial.node_tree.links.new(bsdf.inputs['Base Color'],
                        #                            tex_node.outputs['Color'])
                        #blMaterial.node_tree.links.new(bsdf.inputs['Alpha'],
                        #                            tex_node.outputs['Alpha'])
                        break                
        self.material = blMaterial
        matExtHeader = RWChunk(self.bs)
        # self.bs.seek(matExtHeader.chunkSize,1)
        matExtEndOfs = self.bs.tell() + matExtHeader.chunkSize
        if matExtHeader.chunkSize > 0:
            while self.bs.tell() < matExtEndOfs:
                chunk = RWChunk(self.bs)
                if chunk.chunkID == 0x895303:
                    self.ReadMKMaterial()
                else:
                    self.bs.seek(chunk.chunkSize, SEEK_CUR)
        return texName

    def ReadMKMaterial(self):
        flag = self.bs.readInt()
        self.material.mk.type = flag & 0xffff
        # 0xE000 0x6000 use for skin model , 0x0 is no skin.
        first = flag & 0xffff
        second = flag >> 16
        unk1 = self.bs.readShort()
        unk2 = self.bs.readShort()
        unk3 = self.bs.readFloat()
        self.material.mk.unk1 = unk1
        self.material.mk.unk2 = unk2
        self.material.mk.unk3 = unk3
        if first >= 2:
            if flag & 0x40000000:  # &后为真的话，代表有骨头调色板
                self.useBonePalette = True
                numBoneIDs = self.bs.readInt()
                for i in range(numBoneIDs):
                    self.MKMaterialSkinBonePalette.append(self.bs.readInt())
                # print(self.MKMaterialSkinUsedBoneIDList)
            else:
                self.useBonePalette = False
                self.MKMaterialSkinBonePalette.append(0)
                self.MKMaterialSkinBonePalette.append(0)
                self.MKMaterialSkinBonePalette.append(0)

        if first >= 3:
            # Specular color RGBA dig by ermaccer
            self.material.mk.spec_r = self.bs.readUByte()
            self.material.mk.spec_g = self.bs.readUByte()
            self.material.mk.spec_b = self.bs.readUByte()
            self.material.mk.spec_a = self.bs.readUByte()
        if first >= 4:
            self.material.mk.unk5 = self.bs.readFloat()
            self.material.mk.unk6 = self.bs.readFloat()
            if second & 0x8000:
                self.material.mk.uv_scroll = True
                #self.bs.seek(16, SEEK_CUR)  # uv scroll x/y/z speed. dig by ermaccer
                self.material.mk.uv_scroll_speed_x = self.bs.readFloat()
                self.material.mk.uv_scroll_speed_y = self.bs.readFloat()
                self.material.mk.uv_scroll_speed_z = self.bs.readFloat()
                pad = self.bs.readFloat()
        if first >= 5:
            meshType = self.bs.readInt()
            self.meshTypeFlag = meshType


class rMaterialList(object):
    def __init__(self, datas):
        self.bs = BinaryStream(datas)
        # self.bs = bs
        self.matCount = 0
        self.matList = []
        self.texList = []
        self.MKMaterialList = []
        self.MKMaterialSkinBonePalette = []
        self.useBonePalette = False

    def rMaterialListStruct(self):
        header = RWChunk(self.bs)
        self.matCount = self.bs.readUInt()
        self.bs.seek(self.matCount * 4, 1)

    def getMaterial(self):
        global InputName
        self.rMaterialListStruct()
        for i in range(self.matCount):
            matData = self.bs.readBytes(RWChunk(self.bs).chunkSize)
            mat = rMatrial(matData, i)
            # mat = rMatrial(self.bs)
            texName = mat.rMaterialStruct()
            self.texList.append(texName)
            self.MKMaterialList.append(mat)
            self.matList.append(mat.material)
            # texture = NoeTexture()
            if len(mat.MKMaterialSkinBonePalette) > 0:
                self.MKMaterialSkinBonePalette.append(mat.MKMaterialSkinBonePalette)
            self.useBonePalette = mat.useBonePalette
            # pstr = "MatID:%d " %(i)
            # print(pstr,mat.MKMaterialSkinUsedBoneIDList)
        # return self.matList


class rSkin(object):
    def __init__(self, datas, numVert, nativeFlag, version):
        self.bs = BinaryStream(datas)
        self.numVert = numVert
        self.nativeFlag = nativeFlag
        self.boneIndexs = bytes()
        self.boneWeights = bytes()
        self.usedBoneIndexList = []
        self.version = version
        self.pspBonePalettes = []
        self.skinBoneIndices = []
        self.skinBoneWeights = []
        self.maxNumWeights = 0
    def readSkin(self):
        if self.nativeFlag == 0:
            boneCount = self.bs.readByte()
            usedBoneIDCount = self.bs.readByte()
            self.maxNumWeights = self.bs.readByte()
            unk2 = self.bs.readByte()
            self.bs.seek(usedBoneIDCount, 1)
            self.boneIndexs = self.bs.readBytes(self.numVert * 4)
            self.boneWeights = self.bs.readBytes(self.numVert * 16)
            inverseBoneMats = []
            self.usedBoneIndexList = []
            for i in range(boneCount):
                if self.version < 0x34000 and self.maxNumWeights == 0:
                    flag = self.bs.readInt()
                    self.usedBoneIndexList.append(flag >> 24)
                inverseBoneMats.append(GetMatrix4x4(self.bs.readBytes(64)))
            '''
            for w in range(self.numVert):
                weights = struct.unpack('<4f', self.boneWeights[w * 16: w * 16 + 16])
                b1, b2, b3, b4 = (0, 0, 0, 0)
                if weights[0] > 0:
                    b1 = struct.unpack('B', self.boneIndexs[w * 4:w * 4 + 1])[0]
                    if self.version < 0x34000: b1 = self.usedBoneIndexList[b1]
                if weights[1] > 0:
                    b2 = struct.unpack('B', self.boneIndexs[w * 4 + 1:w * 4 + 2])[0]
                    if self.version < 0x34000: b2 = self.usedBoneIndexList[b2]
                if weights[2] > 0:
                    b3 = struct.unpack('B', self.boneIndexs[w * 4 + 2:w * 4 + 3])[0]
                    if self.version < 0x34000: b3 = self.usedBoneIndexList[b3]
                if weights[3] > 0:
                    b4 = struct.unpack('B', self.boneIndexs[w * 4 + 3:w * 4 + 4])[0]
                    if self.version < 0x34000: b4 = self.usedBoneIndexList[b4]
                self.skinBoneIndices.append((b1, b2, b3, b4))
                self.skinBoneWeights.append(weights)
            '''
            # if not isMKPS2:
            #    self.bs.read('3f')

        else:   # nativeFlag == 1
            skinStruct = RWChunk(self.bs)
            platform = self.bs.readUInt()
            boneCount = self.bs.readUByte()
            numUsedBone = self.bs.readUByte()
            maxWeightsPerVertex = self.bs.readUByte()
            padding = self.bs.readUByte()

            # if isMKPS2:
            if platform == 4:
                self.usedBoneIndexList = []
                for i in range(numUsedBone):
                    self.usedBoneIndexList.append(self.bs.readUByte())
                inverseBoneMats = []
                # for i in range(boneCount):
                #     inverseBoneMats.append(NoeMat44.fromBytes(self.bs.readBytes(64)))
            # if isMKPSP:
            if platform == 10:
                inverseBoneMats = []
                # for i in range(boneCount):
                #     inverseBoneMats.append(NoeMat44.fromBytes(self.bs.readBytes(64)))
                self.bs.seek(20, SEEK_CUR)
                boneLimit = self.bs.readInt()
                numSplit = self.bs.readInt()
                numBonePalette = self.bs.readInt()
                self.usedBoneIndexList = []
                if numSplit:
                    for i in range(boneCount):
                        self.usedBoneIndexList.append(self.bs.readUByte())

                table1Offset = self.bs.tell()
                table2Offset = self.bs.tell() + numSplit * 2

                for i in range(numSplit):
                    self.bs.seek(table1Offset + i * 2)
                    table2ID = self.bs.readUByte()
                    numID = self.bs.readUByte()
                    boneIDs = []
                    self.bs.seek(table2Offset + table2ID * 2)
                    for b in range(numID):
                        boneID = self.bs.readUByte()
                        boneCount = self.bs.readUByte()
                        for bi in range(boneCount):
                            boneIDs.append(boneID + bi)
                    self.pspBonePalettes.append(boneIDs)

            # self.bs.read('7i') #for ps2 dff
            # self.bs.seek(16,1) #for Mortal Kombat PS2


class rBinMeshPLG(object):
    def __init__(self, datas, matList, nativeFlag):
        self.bs = BinaryStream(datas)
        # self.bs = bs
        self.matList = matList
        self.nativeFlag = nativeFlag
        self.matIdList = []
        self.matNameList = []
        self.matIdNumFaceList = []
        self.indicesMatIDs = []
        self.faceIndices = []
        self.tristrips = []
        self.facesList = []
        self.facesMaterialIndices = []
        self.faces = []
        self.numSplitMatID = 0
        self.faceType = 0
        self.indicesCount = 0
    def readFace(self):
        self.faceType = self.bs.readInt()  # 1 = triangle strip
        self.numSplitMatID = self.bs.readUInt()
        self.indicesCount = self.bs.readUInt()
        for i in range(self.numSplitMatID):
            numFaceIndices = self.bs.readUInt()
            matID = self.bs.readUInt()
            self.matIdList.append(matID)
            self.matIdNumFaceList.append(numFaceIndices)
            if self.nativeFlag != 1:
                matName = self.matList[matID].name
                self.matNameList.append(matName)
                tristrips = self.bs.readBytes(numFaceIndices * 4)
                self.tristrips.append(tristrips)
                indices = struct.unpack(numFaceIndices * "I", tristrips)
                faces = []
                if self.faceType == 1:
                    for idx in range(numFaceIndices):
                        if idx > 1:
                            f1 = indices[idx-2]
                            f2 = indices[idx-1]
                            f3 = indices[idx]
                            if f1 != f2 and f2 != f3 and f1 != f3:
                                if idx % 2 == 0:
                                    self.faces.append((f1, f2, f3))
                                    faces.append((f1, f2, f3))
                                else:
                                    self.faces.append((f2, f1, f3))
                                    faces.append((f2, f1, f3))
                                self.facesMaterialIndices.append(matID)
                    self.facesList.append(faces)
                    # print(faces)
                for vertID in indices:
                    self.indicesMatIDs.append(matID)
                    self.faceIndices.append(vertID)


class decodePS2VIF(object):

    def __init__(self, code):
        self.immediate = code & 0xffff
        self.num = (code >> 16) & 0xff
        self.cmd = (code >> 24) & 0x7f
        self.interrupt = (code >> 31) & 1


class decodePS2VIFUnpack(object):

    def __init__(self, cmd, bs:BinaryStream):

        # VU Mem address in transfer destination (address divided by 16.)
        self.address = cmd & 0x3ff
        # 0 = signed data.  1 = unsigned data
        self.unsigned = (cmd >> 14) & 1
        # Address mode (VIF1 only)
        # 1 Adds VIF1_TOPS register to ADDR.
        # 0 Does not use VIF1_TOPS register.
        self.flg = (cmd >> 15) & 1
        self.number = (cmd >> 16) & 0xff
        self.vl = (cmd >> 24) & 3
        self.vn = (cmd >> 26) & 3
        # The m bit shows the presence of the supplementation and mask processing.
        self.m = (cmd >> 28) & 1
        self.cmd = (cmd >> 29) & 3
        # interrupt flag.
        # The i bit shows the presence of the interrupt after processing is performed.
        self.interrupt = (cmd >> 31) & 1
        self.command = (cmd >> 24) & 0xf
        self.numElems = self.vn + 1
        if self.vl == 0:
            self.elemBits = 32
        elif self.vl == 1:
            self.elemBits = 16
        elif self.vl == 2:
            self.elemBits = 8
        elif self.vl == 3:
            # 0xF
            self.elemBits = 5 # 5+5+5+1 bits
        if self.number:
            dataSize = self.number * self.numElems * (self.elemBits // 8)
            if self.command == 0xF:
                dataSize = self.number * 2
            self.data = bs.readBytes(dataSize)
            if dataSize % 4:
                padLen = 4 - (dataSize % 4)
                bs.seek(padLen, SEEK_CUR)
        else:
            self.data = None


def unpackPS2VIF(data):
    unpacks = []
    bs = BinaryStream(data)
    while bs.tell() < bs.dataSize:
        cmd = bs.readUInt()
        vifcode = decodePS2VIF(cmd)
        if vifcode.cmd == 0x20:
            # STMASK
            VIFn_MASK = bs.readInt()
        elif vifcode.cmd == 0x30:
            # STROW
            VIFn_R0_R3 = struct.unpack("<4i",bs.readBytes(16))
        elif vifcode.cmd == 0x31:
            # STCOL
            VIFn_C0_C3 = struct.unpack("<4i",bs.readBytes(16))
        elif vifcode.cmd & 0x60 == 0x60:
            # UNPACK
            unpack = decodePS2VIFUnpack(cmd, bs)
            if unpack.data != None:
                unpacks.append(unpack)
    return unpacks



class rMKPS2NativeDataPLG(object):
    def __init__(self, bs: BinaryStream, matList, binMeshPLG, vertMat, \
                MKMaterialSkinBonePalette, skinFlag, HAnimSkinBoneIDList, \
                useBonePalette, MKMaterialList, armature_obj,\
                vertexGroupNames, index, frame_list, atomic_list):
        # self.bs = BinaryStream(natvieDatas)
        self.bs = bs
        self.matList = matList
        self.matIdList = binMeshPLG.matIdList
        self.matIdNumFaceList = binMeshPLG.matIdNumFaceList
        self.vertMat = vertMat
        self.MKMaterialSkinBonePalette = MKMaterialSkinBonePalette
        self.skinFlag = skinFlag
        self.HAnimSkinBoneIDList = HAnimSkinBoneIDList
        self.useBonePalette = useBonePalette
        # self.skinPlgBoneMap = skinPlgBoneMap
        self.MKMaterialList = MKMaterialList
        self.armature_obj = armature_obj
        self.vertexGroupNames = vertexGroupNames
        self.index = index
        self.frame_list = frame_list
        self.atomic_list = atomic_list
    def readMesh(self):
        # print("bone palette on/off state:", self.useBonePalette)
        startIndex = 0
        faces = []
        facesMaterialIndices = []
        vertices = []
        normalsList = []
        normals = []
        uv1s = []
        colors = []
        skinBoneIndices = []
        skinBoneWeights = []

        splitCount = len(self.matIdList)
        for i in range(splitCount):
            dataSize = self.bs.readUInt()
            meshType = self.bs.readUInt()
            endOfs = self.bs.tell() + dataSize

            padLen1 = ((self.bs.tell() + 127) & 0xFFFFFF80) - self.bs.tell()
            padLen2 = 128 - padLen1
            self.bs.seek(padLen1, SEEK_CUR) # padding128 chunk 1
            vifSize = dataSize - 128
            vifData = self.bs.readBytes(vifSize)
            unpackData = unpackPS2VIF(vifData)
            paddingLength = endOfs - self.bs.tell() # padding128 chunk 2
            self.bs.seek(paddingLength, SEEK_CUR)
            # print(unpackData)
            vertDatas = []
            UVDatas = []
            normalDatas = []
            colorDatas = []
            faceDatas = []
            skinBoneIDs = []
            skinWeights = []
            realNumVertsList = []
            prevStripIDList = []
            vertIDList1Array = []
            vertIDList2Array = []
            sharedVertexIDList = []
            MKPS2SkinDatas = []

            count0x71 = 4
            SkinUVMeshInfoList = []

            # MKA 单骨头武器模型带SKIN PLG区块，但没有权重0x71区块。MK材质里没有骨头调色板列表，标志0x00000005。
            # MKD 单骨头武器模型带SKIN PLG区块，但有权重0x71区块。MK材质有骨头调色板列表，标志0x60000005。

            # Mesh Type 128 Player COSTUME / Weapon skined model. 0x6000 flag.
            # MKMaterial has bone palette, has 0x71 weights chunk.
            if self.MKMaterialList[self.matIdList[i]].meshTypeFlag == 128:
                count0x71 = 4
                self.skinFlag = True
                BonePalette = self.MKMaterialSkinBonePalette[self.matIdList[i]]

            # Mesh Type 129 Weapon skined model.
            # 0xE000 & 0x8000 special data flag.
            # MKMaterial has bone palette, has 0x71 weights chunk.
            elif self.MKMaterialList[self.matIdList[i]].meshTypeFlag == 129:
                count0x71 = 4
                self.skinFlag = True
                BonePalette = self.MKMaterialSkinBonePalette[self.matIdList[i]]

            # Mesh Type 130 Player Reflect / WEAPON_RF No UV skined model.
            # MKMaterial has bone palette, has 0x6E single weight chunk.
            # no 0x71 index/weights chunk.
            elif self.MKMaterialList[self.matIdList[i]].meshTypeFlag == 130:
                self.skinFlag = True
                BonePalette = self.MKMaterialSkinBonePalette[self.matIdList[i]]

            # Mesh Type 131 NPC / Player DECOY skined model.
            # MKMaterial no bone palette, has 0x71 weights chunk.
            # BonePalette in HAnimSkinBoneIDList (HAnim list id).
            elif self.MKMaterialList[self.matIdList[i]].meshTypeFlag == 131:
                self.skinFlag = True
                count0x71 = 4
                BonePalette = self.HAnimSkinBoneIDList

            # Mesh Type 132 Stage model.
            # No 0x71 chunks.
            elif self.MKMaterialList[self.matIdList[i]].meshTypeFlag == 132:
                count0x71 = 0
                self.skinFlag = False

            # Mesh Type 137 MKA Weapon / Stage model.
            # MKMaterial no bone palette , no 0x71 weights chunk.
            # Whether there is a SKIN PLG section depends on GEO.SkinFlag = True.
            elif self.MKMaterialList[self.matIdList[i]].meshTypeFlag == 137:
                count0x71 = 2
                self.skinFlag = False

            vertStripIndex = -1

            # Mesh Type 128, 129 Player COSTUME / Weapon skined model.
            # Has UV Player SkinedModel , need reorder vertex list and copy new vertex to new list.
            # Bonemap in MKMaterial bones list(id is haim list id).
            # BoneID1 = vx & 0x3ff / 4 - 1
            # BoneID2 = vy & 0x3ff / 4 - 1
            # BoneID3 = vz & 0x3ff / 4 - 1
            # 0x68 - vertex
            # 0x6A - normal
            # 0x65 - uv
            # 0x6E - 8bytes. vertex info section. byte4 = real numVert.
            # 0x6D - Vertex shared list (the vertex ID of the previous strip to the next strip).\
            #        The first triangle strip does not contain this data.
            # 0x6D - if current strip missing some vertex id then will have this section.
            # 0x71 chunk 1 = vertex index list 1 short value; skipFlag = value & 0x8000
            # 0x71 chunk 4 = vertex index list 2 short value; skipFlag = value & 0x8000
            # 0x71 chunk 2 = skin/vertex weights chunk, USHORT weight1/4096.0;
            # 0x71 chunk 3 = skin/vertex weights chunk, USHORT weight2/4096.0;
            # 0x71 boneID is HAnimListID

            # Mesh Type 130 Player REFLECT / WEAPON_RF no UV skined model.
            # No UV SkinedModel
            # MKMaterial has bone palette
            # 0x68 Vertex float[3]
            # 0x6A Normals byte[3]
            # 0x6E 4bytes. UBYTE1 boneid/4 - 1 ; UBYTE2 and UBYTE3 is zero; UBYTE4 skipFlag;

            # Mesh Type 131 NPC / Player DECOY skined model.
            # Has UV NPC SkinedModel
            # BonePalette in HAnimSkinBoneIDList (HAnim list id).
            # MKMaterial no bone palette.
            # 0x68 vertex, 0x6A normal, 0x65 uv, 0x6D vertex shared list.
            # 0x71 chunk x 4. same as Mesh Type 128.


            # Mesh Type 132,135 Stage model. sample: edenia\\tiles.dff
            # 0x68 Vertex float[3]
            # 0x64 UV float[2]
            # 0x6E Colors RGBA ubyte[4]
            # 0x6A Normals byte[3]

            # Mesh Type 133 Stage model, sample: darkprison mkd\BACKGROUND.dff
            # 0x68 Vertex float[3]
            # 0x64 UV float[2]
            # 0x6A Normals byte[3]
            # 0x71 chunk1 and chunk2 vertex index remap short;

            # Mesh Type 136 Stage model, same as 137. sample: darkprison mkd\BACKGROUND.dff
            # Mesh Type 138 Stage model, same as 137. sample: battle_arena mka\BACKGROUND.dff
            # Mesh Type 141 Stage model, same as 137. sample: battle_arena mka\BACKGROUND.dff

            # Mesh Type 137 MKA Weapon / Stage model.
            # Has UV Non-SkinedModel MapMesh
            # 0x6C 16bytes Bounding Sphere XYZ_RAD. float[4] 
            # 0x64 UV float[2]
            # 0x68 Vertex float[3]
            # 0x6A Normals byte[3]
            # 0x6C UV1+UV2 float[4]
            # 0x6A byte[3] Normals_2
            # 0x6E Colors RGBA ubyte[4]
            # 0x71 chunk1 and chunk2 vertex index remap short;

            mapVertIdInterval = 0
            for up in unpackData:
                if up.numElems == 3 and up.elemBits == 32:      # 0x68000000
                    vertStripIndex += 1
                    vertDatas.append(up.data)
                elif up.numElems == 2 and up.elemBits == 16:    # 0x65000000
                    UVDatas.append(getUV(up.data))
                elif up.numElems == 2 and up.elemBits == 32:    # 0x64000000
                    UVDatas.append(up.data)
                elif up.numElems == 4 and up.elemBits == 32:    # 0x6C000000
                    if len(up.data) > 16: # skip mesh type 137 bounding sphere XYZR 16 bytes
                        # UV1
                        numV = len(up.data) // 16
                        uv1 = bytearray(numV * 8)
                        for u in range(numV):
                            uv1[u * 8: u * 8 + 8] = up.data[u * 16: u * 16 + 8]
                        UVDatas.append(uv1)
                        # TODO UV2 support
                elif up.numElems == 3 and up.elemBits == 8:     # 0x6A000000
                    if len(normalDatas) < len(vertDatas):       # skip second 0x6A
                        normalsData = getNormal(up.data)
                        normalDatas.append(normalsData)
                elif up.numElems == 1 and up.elemBits == 16:    # 0x71000000 (0x61000000)
                    if self.skinFlag:
                        if count0x71 % 4 == 0:
                            vertIDList1 = getVertexIDListSkinMesh(up.data, self.useBonePalette)
                            vertIDList1Array.append(vertIDList1)
                        if count0x71 % 4 == 3:
                            vertIDList2 = getVertexIDListSkinMesh(up.data, self.useBonePalette)
                            vertIDList2Array.append(vertIDList2)
                        if count0x71 % 4 == 1:
                            MKPS2SkinDatas.append(up.data)
                        if count0x71 % 4 == 2:
                            MKPS2SkinDatas.append(up.data)
                    else:
                        if count0x71 % 2 == 0:
                            vertIDList1 = getVertexIDListMapMesh(up.data)
                            vertIDList1Array.append(vertIDList1)
                            mapVertIdInterval = vertIDList1[5]
                        if count0x71 % 2 == 1:
                            vertIDList2 = getVertexIDListMapMesh(up.data)
                            vertIDList2Array.append(vertIDList2)
                            mapVertIdInterval = vertIDList2[5]
                    count0x71 += 1
                elif up.numElems == 4 and up.elemBits == 8:     # 0x6E000000
                    if self.skinFlag:
                        if len(up.data) > 8:  # skip 8 bytes has uv skined model header data
                            # REFLECT - No UV MESH - BoneID / Skip Flag chunk
                            faceAndSkinData = createTriListNoUVMesh(up.data, BonePalette)
                            faceDatas.append(faceAndSkinData[0])
                            skinBoneIDs.append(faceAndSkinData[1])
                            skinWeights.append(faceAndSkinData[2])
                        else:
                            # COSTUME 8 bytes header- SKIN HAS UV MESH
                            realNumVertsList.append(struct.unpack("B", up.data[3:4])[0])
                            SkinUVMeshInfoList.append(up.data)
                            # first8ByteStr = "%d,%d,%d,%d,%d,%d,%d,%d\n" \
                            # %(up.data[0],up.data[1],up.data[2],up.data[3],\
                            # up.data[4],up.data[5],up.data[6],up.data[7])
                            # print(first8ByteStr)
                    elif len(up.data) > 4:
                        # BACKGROUND - Stage Model - Colors
                        colorDatas.append(up.data)
                    elif len(up.data) == 4:
                        # BACKGROUND / WEAPON - 4 bytes header data
                        realNumVertsList.append(struct.unpack("B", up.data[3:4])[0])
                        first4ByteStr = "%d,%d,%d,%d\n" % (up.data[0], up.data[1], \
                                                           up.data[2], up.data[3])
                        # print(first4ByteStr)
                elif up.numElems == 4 and up.elemBits == 16:    # 0x6D000000
                    if self.skinFlag:
                        sharedIDList = getsharedVertexIDListSkinMesh(up.data, self.useBonePalette)
                        sharedVertexIDList.append([(vertStripIndex + 1), sharedIDList])
                    else:
                        sharedIDList = getsharedVertexIDListMapMesh(up.data, mapVertIdInterval)
                        sharedVertexIDList.append([(vertStripIndex + 1), sharedIDList])
            matID = self.matIdList[i]
            matName = self.matList[matID].name


            newVertDatas = []
            newUVDatas = []
            newNormalDatas = []
            newColorDatas = []
            newSkipListDatas = []
            newSkinBoneIDs = []
            newSkinWeights = []
            if len(vertIDList1Array) and self.skinFlag:
                skinWeights = getMKPS2VertexWeights(MKPS2SkinDatas)
                skinBoneIDs = getMKPS2VertexBoneIDs(vertDatas, BonePalette,\
                    self.HAnimSkinBoneIDList, self.useBonePalette)
            numVertBlock = len(vertDatas)
            totalVertCount = 0
            # 根据现有数据填充生成顶点列表
            for v in range(numVertBlock):
                tempFaceDatas = []
                # rapi.rpgSetName("mesh"+str(i) + "_" + str(v))
                # print("mesh"+str(i) + "_" + str(v))
                # print("vert buffer strip id:",v)
                vertBuffer = vertDatas[v]
                numVert = len(vertBuffer) // 12
                if numVert <= 2:
                    continue
                normalData = normalDatas[v]
                if len(UVDatas):
                    UVData = UVDatas[v]
                if len(colorDatas):
                    colorData = colorDatas[v]
                if len(skinBoneIDs):
                    # print("boneid size:",len(skinBoneIDs[v]))
                    boneIDs = skinBoneIDs[v]
                    weights = skinWeights[v]

                if len(vertIDList1Array) and numVert > 2:  # and self.skinFlag:
                    # print(vertIDList1Array[v][0])
                    vertCount = realNumVertsList[v]
                    if not self.skinFlag:
                        maxVertID = 0
                        if maxVertID < vertIDList1Array[v][3]:
                            maxVertID = vertIDList1Array[v][3]
                        if maxVertID < vertIDList2Array[v][3]:
                            maxVertID = vertIDList2Array[v][3]
                        if v > 0:
                            for j in range(len(sharedVertexIDList)):
                                if sharedVertexIDList[j][0] == v:
                                    for s in range(len(sharedVertexIDList[j][1][0])):
                                        curStripVertID = sharedVertexIDList[j][1][1][s]
                                        if maxVertID < curStripVertID:
                                            maxVertID = curStripVertID
                        vertCount = maxVertID + 1
                    # print("vertCount:",vertCount)
                    totalVertCount += vertCount
                    padVec3 = (0.0, 0.0, 0.0)
                    padNomral = (0.0, 0.0, 0.0)
                    padUV = struct.unpack('2f', UVData[0:8])

                    vertList = [padVec3] * vertCount
                    normalList = [padNomral] * vertCount
                    uvList = [padUV] * vertCount
                    colorList = [[0, 0, 0, 0]] * vertCount
                    boneIDList = [[0, 0, 0]] * vertCount
                    weightList = [[0.0, 0.0, 0.0]] * vertCount

                    if len(skinBoneIDs):
                        padBoneID = struct.unpack('3B', boneIDs[0:3])
                        padWeight = struct.unpack('3f', weights[0:12])
                        boneIDList = [padBoneID] * vertCount
                        weightList = [padWeight] * vertCount
                    if len(colorDatas):
                        padColor = struct.unpack('4B', colorData[0:4])
                        colorList = [padColor] * vertCount
                    skipList = [True] * vertCount
                    vertIDList = [False] * vertCount
                    vertIDList2 = ["missing"] * vertCount
                    for j in range(len(vertIDList1Array[v][0])):
                        vertID = vertIDList1Array[v][0][j]
                        # print(vertID,j,len(vertList),len(vertBuffer)//12)
                        vertList[vertID] = struct.unpack("<3f", vertBuffer[j * 12: j * 12 + 12])
                        normalList[vertID] = struct.unpack("<3f", normalData[j * 12: j * 12 + 12])
                        uvList[vertID] = struct.unpack('2f', UVData[j * 8: j * 8 + 8])
                        skipList[vertID] = vertIDList1Array[v][2][j]
                        vertIDList[vertID] = True
                        vertIDList2[vertID] = 1
                        if len(skinBoneIDs):
                            # print(len(vertIDList1Array[v][0]),j,boneIDs[j*3:j*3+3])
                            boneIDList[vertID] = struct.unpack('3B', boneIDs[j * 3: j * 3 + 3])
                            weightList[vertID] = struct.unpack('3f', weights[j * 12: j * 12 + 12])
                        if len(colorDatas):
                            colorList[vertID] = struct.unpack('4B', colorData[j * 4: j * 4 + 4])
                    for j in range(len(vertIDList2Array[v][0])):
                        vertID = vertIDList2Array[v][0][j]
                        # print(vertID,len(vertBuffer)//12)
                        vertList[vertID] = struct.unpack("<3f", vertBuffer[j * 12: j * 12 + 12])
                        normalList[vertID] = struct.unpack("<3f", normalData[j * 12: j * 12 + 12])
                        uvList[vertID] = struct.unpack('2f', UVData[j * 8: j * 8 + 8])
                        skipList[vertID] = vertIDList2Array[v][2][j]
                        vertIDList[vertID] = True
                        vertIDList2[vertID] = 1
                        if len(colorDatas):
                            colorList[vertID] = struct.unpack('4B', colorData[j * 4: j * 4 + 4])
                        if len(skinBoneIDs):
                            boneIDList[vertID] = struct.unpack('3B', boneIDs[j * 3: j * 3 + 3])
                            weightList[vertID] = struct.unpack('3f', weights[j * 12: j * 12 + 12])
                    # print("mesh" + str(i) + "_" + str(v))
                    # print(vertIDList2)
                    # print("ori:",(len(vertBuffer) // 12 ),"new:",vertCount)
                    if v > 0:
                        for j in range(len(sharedVertexIDList)):
                            if sharedVertexIDList[j][0] == v:
                                # print(sharedVertexIDList[j][1][0])
                                # print(sharedVertexIDList[j][1][1])
                                for s in range(len(sharedVertexIDList[j][1][0])):
                                    prevStripVertID = sharedVertexIDList[j][1][0][s]
                                    curStripVertID = sharedVertexIDList[j][1][1][s]
                                    vid = prevStripVertID
                                    prevStripID = v - 1
                                    # print(curStripVertID,vid)
                                    vertList[curStripVertID] = struct.unpack("<3f", \
                                        newVertDatas[prevStripID][vid * 12: vid * 12 + 12])
                                    normalList[curStripVertID] = struct.unpack("<3f", \
                                        newNormalDatas[prevStripID][vid * 12: vid * 12 + 12])
                                    uvList[curStripVertID] = struct.unpack('2f', \
                                        newUVDatas[prevStripID][vid * 8: vid * 8 + 8])
                                    skipList[curStripVertID] = sharedVertexIDList[j][1][2][s]
                                    if len(skinBoneIDs):
                                        boneIDList[curStripVertID] = struct.unpack('3B', \
                                            newSkinBoneIDs[prevStripID][vid * 3: vid * 3 + 3])
                                        weightList[curStripVertID] = struct.unpack('3f', \
                                            newSkinWeights[prevStripID][vid * 12: vid * 12 + 12])
                                    vertIDList2[curStripVertID] = "prev" + str(vid)
                    # print(vertIDList2)
                    newVertBuffer = bytes()
                    newNormalBuffer = bytes()
                    newUVBuffer = bytes()
                    newColorBuffer = bytes()
                    newBoneIDBuffer = bytes()
                    newWeightBuffer = bytes()
                    for j in range(vertCount):
                        vert = vertList[j]
                        # newVertBuffer += vert.toBytes()
                        newVertBuffer += struct.pack("<3f", vert[0],  vert[1],  vert[2])
                        normal = normalList[j]
                        # newNormalBuffer += normal.toBytes()
                        newNormalBuffer += struct.pack("<3f", normal[0], normal[1], normal[2])
                        uv = uvList[j]
                        newUVBuffer += struct.pack('2f', uv[0], uv[1])
                        if len(colorDatas):
                            color = colorList[j]
                            newColorBuffer += struct.pack('4B', \
                                color[0], color[1], color[2], color[3])
                        if len(skinBoneIDs):
                            tempBoneIDs = boneIDList[j]
                            tempWeights = weightList[j]
                            newBoneIDBuffer += struct.pack('3B', \
                                tempBoneIDs[0], tempBoneIDs[1], tempBoneIDs[2])
                            newWeightBuffer += struct.pack('3f', \
                                tempWeights[0], tempWeights[1], tempWeights[2])
                    vertBuffer = newVertBuffer
                    newVertDatas.append(newVertBuffer)
                    normalData = newNormalBuffer
                    newNormalDatas.append(newNormalBuffer)
                    UVData = newUVBuffer
                    newUVDatas.append(newUVBuffer)
                    newSkipListDatas.append(skipList)
                    faceBuffer = createTriList(skipList)
                    # faceBuffer = getTriangleList(vertBuffer,1)

                    tempFaceDatas.append(faceBuffer)
                    if len(colorDatas):
                        colorData = newColorBuffer
                        newColorDatas.append(newColorBuffer)
                    if len(skinBoneIDs):
                        boneIDs = newBoneIDBuffer
                        weights = newWeightBuffer
                        newSkinBoneIDs.append(newBoneIDBuffer)
                        newSkinWeights.append(newWeightBuffer)
                #if self.skinFlag:
                vertBuffer = getTransformVertex(vertBuffer, self.vertMat, self.skinFlag)
                # print("vertices has tranformed")
                numVert = len(vertBuffer) // 12
                tempVertices = []
                for vi in range(numVert):
                    vertex = struct.unpack("<3f",vertBuffer[vi * 12:vi * 12 + 12])
                    vertices.append(vertex)
                    tempVertices.append(vertex)

                # print("numVert:",numVert)
                #if self.skinFlag:
                normalData = getTransformNormal(normalData, self.vertMat)
                tempNormals = []
                for vi in range(numVert):
                    normal = struct.unpack("<3f",normalData[vi * 12:vi * 12 + 12])
                    normalsList.append(normal)
                    tempNormals.append(normal)

                if len(UVDatas):
                    for uv in range(numVert):
                        uv = struct.unpack('<2f',UVData[uv * 8:uv * 8 + 8])
                        uv1s.append((uv[0],1.0 - uv[1]))
                #if len(colorDatas) and len(vertIDList1Array) > 0:
                if len(colorDatas):
                    for c in range(numVert):
                        col = struct.unpack("<4B",colorData[c * 4:c * 4 + 4])
                        colors.append((col[0]/255,col[1]/255,col[2]/255,col[3]/255))

                # matID = self.matIdList[i]
                # matName = self.matList[matID].name
                # matName = "mtl" + str(i) + "_" + str(v)

                if len(skinBoneIDs):
                    if len(skinBoneIDs[v]) // numVert == 4:          # for no uv skined model
                        for bi in range(numVert):
                            skinBoneIndices.append(struct.unpack("<I",\
                                skinBoneIDs[v][bi * 4:bi * 4 + 4]) )
                            skinBoneWeights.append(struct.unpack("<f",\
                                skinWeights[v][bi * 4:bi * 4 + 4]))
                    else:
                        # for has uv skined model
                        for bi in range(numVert):
                            skinBoneIndices.append(struct.unpack("<BBB",\
                                boneIDs[bi * 3:bi * 3 + 3]) )
                            skinBoneWeights.append(struct.unpack("<fff",\
                                weights[bi * 12:bi * 12 + 12]))
                if len(faceDatas):
                    if numVert > 2: # "NO UV SKIN MESH"
                        faceBuffer = faceDatas[v]
                        faceBuffer = fix_strip_face_normal(faceBuffer, tempVertices, tempNormals)
                elif len(tempFaceDatas) > 0: # "UV SKIN MESH and Map MESH"
                    faceBuffer = tempFaceDatas[0]
                    faceBuffer = fix_strip_face_normal(faceBuffer, tempVertices, tempNormals)
                elif len(vertIDList1Array) == 0:  # NO 0x71 chunks map mesh
                    faceBuffer = getTriangleList(vertBuffer, 1)
                for f in range(len(faceBuffer) // 12):
                    face = struct.unpack("3i",faceBuffer[f *12:f * 12 +12])
                    faces.append((face[0] + startIndex, \
                                    face[1] + startIndex, face[2] + startIndex))
                    facesMaterialIndices.append(matID)
                # print(i,v,startIndex,numVert,startIndex+numVert,"endFaceCount:",len(faces))
                startIndex += numVert
        mesh = bpy.data.meshes.new("Mesh")
        obj = bpy.data.objects.new("Mesh",mesh)
        bpy.context.scene.collection.objects.link(obj)
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        # meshData = bpy.context.object.data
        '''
        bm = bmesh.new()
        # Vertex
        for v in vertices:
            bm.verts.new(v)
        bm.to_mesh(mesh)


        # Face
        bm.verts.ensure_lookup_table()
        index = 0
        for f in faces:
            # print(index,f)
            bm.faces.new([bm.verts[fi] for fi in f])
            index += 1
        bm.to_mesh(mesh)

        # Material 添加多维材质并导入显示纹理
        names = []
        if self.matList:
            for mat in self.matList:
                if mat.name not in names:
                    names.append(mat.name)
                    obj.data.materials.append(mat)

        # Set Face material index 为每个面指定材质ID
        for f,matID in zip(bm.faces,facesMaterialIndices):
            matName = self.matList[matID].name
            for m in range(len(obj.data.materials)):
                if matName == obj.data.materials[m].name:
                    matID = m
                    break
            f.material_index = matID
        bm.to_mesh(mesh)

        # UV
        if len(uv1s):
            uv_layer = bm.loops.layers.uv.verify()
            bm.faces.ensure_lookup_table()
            for face in bm.faces:
                for loop in face.loops:
                    loop[uv_layer].uv = uv1s[loop.vert.index]
            bm.to_mesh(mesh)
        bm.free()
        '''
        mesh.from_pydata(vertices,[],faces)
        # Material 添加多维材质并导入显示纹理
        names = []
        if self.matList:
            for mat in self.matList:
                if mat.name not in names:
                    names.append(mat.name)
                    obj.data.materials.append(mat)
        # Set Face material index 为每个面指定材质ID
        for f,matID in zip(mesh.polygons,facesMaterialIndices):
            matName = self.matList[matID].name
            for m in range(len(obj.data.materials)):
                if matName == obj.data.materials[m].name:
                    matID = m
                    break
            f.material_index = matID

        if len(uv1s):
            mesh.uv_layers.new(do_init=False)
            mesh.uv_layers[-1].data.foreach_set('uv', [
                vt for uv in [uv1s[loop.vertex_index] for loop in mesh.loops]
                for vt in uv
            ])
        faceNormals = []
        for l in mesh.loops:
            faceNormals.append(normalsList[l.vertex_index])
        mesh.normals_split_custom_set(faceNormals)
        mesh.use_auto_smooth = True
        # print("USE FACE NORMALS")
        # print("Face normal count:",len(faceNormals))
        # print("face loops count",len(mesh.loops))
        # print("Face  count:",len(faces))
        # print("vertices count:",len(vertices))
        # Normals
        #mesh.normals_split_custom_set_from_vertices(normalsList)
        #mesh.use_auto_smooth = True


        # Colors
        if len(colors):
            vcol_layer = mesh.vertex_colors.new()
            for loop,col in zip(mesh.loops, vcol_layer.data):
                col.color = colors[loop.vertex_index]

        # Skin Bone Indices Weights
        if len(skinBoneIndices):
            vertexID = 0
            for boneids,weights in zip(skinBoneIndices, skinBoneWeights):
                for boneid,weight in zip(boneids,weights):
                    if weight != 0:
                        if boneid > len(self.vertexGroupNames) - 1:
                            print("out range id:",boneid)                        
                        groupName = self.vertexGroupNames[boneid]
                        if groupName not in obj.vertex_groups:
                            obj.vertex_groups.new(name = groupName)
                        obj.vertex_groups[groupName].add([vertexID],weight,'ADD')
                vertexID += 1

        # Skin
        if self.armature_obj and len(skinBoneIndices):
            armatureMod = obj.modifiers.new("Armature","ARMATURE")
            armatureMod.object = self.armature_obj
            obj.parent = self.armature_obj
        else:
            obj.parent = self.frame_list.armature_obj
            obj.parent_type = 'BONE'
            for i,atomic in enumerate(self.atomic_list):
                geo_index = atomic.geometryIndex
                if geo_index == self.index:
                    # print(self.frame_list.boneInfoList[atomic.frameIndex].boneName)
                    obj.parent_bone = self.frame_list.boneInfoList[atomic.frameIndex].boneName
                    break
        mesh.update()
        #obj.rotation_euler = (1.570796,0,0)



def fix_strip_face_normal(faceBuffer:bytes, tempVertices, tempNormals):

    # https://github.com/aap/rwio/blob/4121d2f1da8946464f79363d67676f08bf7e293b/src/import.cpp#L575C4-L575C67
    # See if we can figure out a better winding if we have normals

    tempFace = []
    tempFaceBuffer = bytes()
    for f in range(len(faceBuffer) // 12):
        face = struct.unpack("<3i",faceBuffer[f *12:f * 12 +12])
        v1 = Vector(tempVertices[face[1]]) - Vector(tempVertices[face[0]])
        v2 = Vector(tempVertices[face[2]]) - Vector(tempVertices[face[0]])
        norm = v1.cross(v2).copy()
        dot0 = norm.dot(Vector(tempNormals[face[0]]))
        dot1 = norm.dot(Vector(tempNormals[face[1]]))
        dot2 = norm.dot(Vector(tempNormals[face[2]]))
        tempFace.append((face[0],face[1], face[2]))
        if dot0 < 0.0 and dot1 < 0.0  and dot2 < 0.0:
            tempFace[f] = (tempFace[f][0],tempFace[f][2],tempFace[f][1])
        tempFaceBuffer += struct.pack("<3i",tempFace[f][0],tempFace[f][1],tempFace[f][2])
    return tempFaceBuffer


def getMKPS2VertexBoneIDs(flagData, MKMaterialUsedBoneIDList, \
        hanimSkinBoneIDList, useBonePalette):
    numBlock = len(flagData)
    boneIDsList = []
    bonePalette = []
    if useBonePalette:  # player mesh
        # for i in range(len(MKMaterialUsedBoneIDList)):
        #     bonePalette.append(hanimSkinBoneIDList[MKMaterialUsedBoneIDList[i]])
        bonePalette = MKMaterialUsedBoneIDList
    else:               # npc mesh
        bonePalette = hanimSkinBoneIDList
    for i in range(numBlock):
        boneIDs = bytes()
        numVert = len(flagData[i]) // 12
        bs = BinaryStream(flagData[i])
        for j in range(numVert):
            boneID1 = bs.readUInt() & 0x3FF
            boneID2 = bs.readUInt() & 0x3FF
            boneID3 = bs.readUInt() & 0x3FF
            if boneID1 > 0:
                boneID1 = boneID1 // 4 - 1
                boneID1 = bonePalette[boneID1]
            if boneID2 > 0:
                boneID2 = boneID2 // 4 - 1
                boneID2 = bonePalette[boneID2]
            if boneID3 > 0:
                boneID3 = boneID3 // 4 - 1
                boneID3 = bonePalette[boneID3]
            boneIDs += struct.pack('3B', boneID1, boneID2, boneID3)
        boneIDsList.append(boneIDs)
    return boneIDsList


def getMKPS2VertexWeights(flagData):
    numBlock = len(flagData) // 2

    weightsList = []

    for i in range(numBlock):
        bin1 = BinaryStream(flagData[i * 2])
        bin2 = BinaryStream(flagData[i * 2 + 1])
        weights = bytes()
        numVert = len(flagData[i * 2]) // 2

        for j in range(numVert):
            w1 = bin1.readShort()
            w2 = bin2.readShort()
            weight1 = w1 / 4096.0
            weight2 = w2 / 4096.0
            # print(w1,w2,w1+w2)
            weight3 = 0.0
            if (w1 + w2) < 4095:
                weight3 = 1.0 - weight1 - weight2
            weights += struct.pack('3f', weight1, weight2, weight3)
        weightsList.append(weights)
    return weightsList


def getsharedVertexIDListSkinMesh(flagData, useBonePalette):
    vin = BinaryStream(flagData)
    numVerts = len(flagData) // 2
    prevStripVertexIDList = []
    curStripVertexIDList = []
    skipList1 = []
    skipList2 = []
    for i in range(numVerts):
        value = vin.readUShort()
        unkFlag = value & 0x2
        skipFlag = (value & 0x8000) == 0x8000
        if useBonePalette:
            if (value & 0x7FFF) < 488:
                vertID = ((value & 0x7FFF) - 130) // 4
            else:
                vertID = ((value & 0x7FFF) - 488) // 4
        else:
            if (value & 0x7FFF) < 634:
                vertID = ((value & 0x7FFF) - 191) // 3
            else:
                vertID = ((value & 0x7FFF) - 634) // 3
        if i % 2 == 0:
            prevStripVertexIDList.append(vertID)
            skipList1.append(skipFlag)
        elif i % 2 == 1:
            curStripVertexIDList.append(vertID)
            skipList2.append(skipFlag)
    return [prevStripVertexIDList, curStripVertexIDList, skipList1, skipList2]


def getVertexIDListSkinMesh(flagData, useBonePalette):
    vin = BinaryStream(flagData)
    numVerts = len(flagData) // 2
    vertIDList = []
    unkFlagList = []
    skipFlagList = []
    # base index 4 type: 130 488 191 634

    testList = []
    for i in range(numVerts):
        value = vin.readUShort()
        unkFlag = value & 0x2
        if useBonePalette:
            if (value & 0x7FFF) < 488:
                vertID = ((value & 0x7FFF) - 130) // 4
            else:
                vertID = ((value & 0x7FFF) - 488) // 4
        else:
            if (value & 0x7FFF) < 634:
                vertID = ((value & 0x7FFF) - 191) // 3
            else:
                vertID = ((value & 0x7FFF) - 634) // 3
        skipFlag = (value & 0x8000) == 0x8000
        if (value & 0x7FFC) >= 0:
            vertIDList.append(vertID)
            unkFlagList.append(unkFlag)
            skipFlagList.append(skipFlag)
        testList.append(value & 0x7fff)
    #print("Ori:",testList)
    #print("sort:",sorted(testList))
    #print("real ori:",vertIDList)
    #print("real sort:",sorted(vertIDList))
    return [vertIDList, unkFlagList, skipFlagList]


def getsharedVertexIDListMapMesh(flagData, mapVertIdInterval):
    vin = BinaryStream(flagData)
    numVerts = len(flagData) // 2
    prevStripVertexIDList = []
    curStripVertexIDList = []
    skipList1 = []
    skipList2 = []
    vertStorageIDList = []
    # print("shared map interval:",mapVertIdInterval)
    for i in range(numVerts):
        value = vin.readUShort()
        value1 = value & 0x7fff
        if mapVertIdInterval % 3 == 0:
            if value1 >= 147 and value1 < 622:
                if (value1 - 147) % 3 > 0:
                    vertID = (value1 - 238) // 3
                else:
                    vertID = (value1 - 147) // 3
            elif value1 >= 622:
                if (value1 - 622) % 3 > 0:
                    vertID = (value1 - 723) // 3
                else:
                    vertID = (value1 - 622) // 3
        elif mapVertIdInterval % 5 == 0:
            if value1 >= 193 and value1 < 671:
                if (value1 - 193) % 5 > 0:
                    vertID = (value1 - 201) // 5
                else:
                    vertID = (value1 - 193) // 5
            elif value1 >= 671:
                if (value1 - 671) % 5 > 0:
                    vertID = (value1 - 679) // 5
                else:
                    vertID = (value1 - 671) // 5
        skipFlag = (value & 0x8000) == 0x8000
        if i % 2 == 0:
            prevStripVertexIDList.append(vertID)
            skipList1.append(skipFlag)
        elif i % 2 == 1:
            curStripVertexIDList.append(vertID)
            skipList2.append(skipFlag)
        vertStorageIDList.append(value & 0x7fff)
    # print("Shared ID LIST:")
    # print(vertStorageIDList)
    # print(prevStripVertexIDList)
    # print(curStripVertexIDList)

    return [prevStripVertexIDList, curStripVertexIDList, skipList1, skipList2]


def getVertexIDListMapMesh(flagData):
    vin = BinaryStream(flagData)
    numVerts = len(flagData) // 2
    vertIDList = []
    unkFlagList = []
    skipFlagList = []

    maxVertID = 0
    vertStorageIDList = []
    test = []
    for i in range(numVerts):
        value = vin.readUShort()
        unkFlag = value & 0x3
        skipFlag = (value & 0x8000) == 0x8000
        unkFlagList.append(unkFlag)
        skipFlagList.append(skipFlag)
        vertStorageIDList.append(value & 0x7fff)
        test.append(value & 0x7fff)

    test.sort()
    intervalList = []
    for i in range(numVerts):
        if i > 0:
            intervalValue = test[i] - test[i - 1]
            intervalList.append(intervalValue)
    intervalList.sort()
    # print(intervalList)
    # print("ID LIST:")
    # print(test)

    firstID = vertStorageIDList[0]
    secondID = vertStorageIDList[1]
    interval = intervalList[0]

    # Base index values
    # MKD 193-5 671-5
    # MKA 201-5 679-5
    # MKD 1-3
    # MKA 147-3 622-3
    # MKA MKD 238-3 723-3 - mesh type 137
    for i in range(numVerts):
        value = vertStorageIDList[i]
        if (interval % 3) == 0:
            if value < 622 and value >= 1:
                if value % 3 == 1:
                    if value >= 238:
                        vertID = (value - 238) // 3
                    else:
                        vertID = (value - 1) // 3
                elif value % 3 == 0:
                    vertID = (value - 147) // 3

            elif value >= 622:
                if (value - 622) % 3 > 0:
                    vertID = (value - 723) // 3
                else:
                    vertID = (value - 622) // 3
        elif (interval % 5) == 0:
            if value < 671 and value >= 193:
                if (value - 193) % 5 > 0:
                    vertID = (value - 201) // 5
                else:
                    vertID = (value - 193) // 5
            elif value >= 671:
                if (value - 671) % 5 > 0:
                    vertID = (value - 679) // 5
                else:
                    vertID = (value - 671) // 5
        vertIDList.append(vertID)
        if maxVertID < vertID:
            maxVertID = vertID
    vertStorageIDList.sort()
    # print("v count: ",len(vertIDList),numVerts)
    # print("v List:",vertIDList)
    return [vertIDList, unkFlagList, skipFlagList, maxVertID, vertStorageIDList, interval]


def createTriList(skipList):
    out = BinaryStream()
    numVerts = len(skipList)
    startDir = -1
    faceDir = startDir
    f1 = 0
    f2 = 1
    for i in range(numVerts):
        f3 = i
        if i > 1:
            skipFlag = skipList[i]  # skip Isolated vertex
            faceDir *= -1
            if skipFlag is not True:
                if faceDir > 0:
                    out.writeInt(f1)
                    out.writeInt(f2)
                    out.writeInt(f3)
                else:
                    out.writeInt(f2)
                    out.writeInt(f1)
                    out.writeInt(f3)
            f1 = f2
            f2 = f3
    return out.getBuffer()


def createTriListNoUVMesh(flagData, usedBoneIDList):
    vin = BinaryStream(flagData)
    out = BinaryStream()
    numVerts = len(flagData) // 4
    faceDir = 1
    f1 = 0
    f2 = 1
    boneIDs = bytes()
    weights = bytes()

    for i in range(numVerts):
        boneID1 = vin.readUByte() // 4  # always only use boneID1
        weight1 = vin.readUByte()  # always 0
        boneID2 = vin.readUByte()  # always 0
        bitFlag = vin.readUByte()  # weight2 always 0
        weight2 = bitFlag & 0xFE

        weights += struct.pack("f", 1.0)
        boneIDs += struct.pack("i", usedBoneIDList[boneID1 - 1])
        f3 = i
        skipFlag = bitFlag & 0x1  # skip Isolated vertex
        if skipFlag != 1:
            if f1 != f2 and f2 != f3 and f3 != f1:
                if faceDir > 0:
                    out.writeInt(f1)
                    out.writeInt(f2)
                    out.writeInt(f3)
                else:
                    out.writeInt(f2)
                    out.writeInt(f1)
                    out.writeInt(f3)
        faceDir *= -1
        f1 = f2
        f2 = f3
    # print("end")
    return [out.getBuffer(), boneIDs, weights]


def getTriangleList(vertBuffer, startDir):
    triangleList = []
    triangleDir = startDir
    for j in range(len(vertBuffer) // 12 - 2):
        v1 = struct.unpack('3f', vertBuffer[j * 12: j * 12 + 12])
        v2 = struct.unpack('3f', vertBuffer[(j + 1) * 12:(j + 1) * 12 + 12])
        v3 = struct.unpack('3f', vertBuffer[(j + 2) * 12:(j + 2) * 12 + 12])
        f1 = j
        f2 = j + 1
        f3 = j + 2
        if v1 != v2 and v2 != v3 and v1 != v3:
            if triangleDir > 0:
                triangleList.append((f1, f2, f3))
            else:
                triangleList.append((f2, f1, f3))
        triangleDir *= -1
    faceBuffer = bytes()
    for j in range(len(triangleList)):
        faceBuffer += struct.pack('3I', triangleList[j][0], triangleList[j][1], triangleList[j][2])
    return faceBuffer


def getTransformVertex(vertBuffer, parentBoneMatrix:Matrix, skinflag=True):
    vin = BinaryStream(vertBuffer)
    out = BinaryStream()
    numVerts = len(vertBuffer) // 12
    rot_matrix = parentBoneMatrix.to_3x3()
    for i in range(numVerts):
        if skinflag:
            vx = vin.readUInt() & 0xFFFFFC00
            vy = vin.readUInt() & 0xFFFFFC00
            vz = vin.readUInt() & 0xFFFFFC00
            temp_bytes = struct.pack("<3I",vx,vy,vz)
            vert = Vector(struct.unpack("<3f",temp_bytes))
        else:
            vert =  Vector(struct.unpack("<3f",vin.readBytes(12)))
        vert = rot_matrix @ vert
        # vert = parentBoneMatrix @ vert
        out.writeBytes(struct.pack("<3f", vert[0], vert[1], vert[2]))
    return out.getBuffer()


def getUV(uvdata):
    uvin = BinaryStream(uvdata)
    out = BinaryStream()
    numVerts = len(uvdata) // 4
    for i in range(numVerts):
        u = uvin.readShort() / 4096.0
        v = uvin.readShort() / 4096.0
        out.writeFloat(u)
        out.writeFloat(v)
    return out.getBuffer()


def getTransformNormal(normalData, parentBoneMatrix:Matrix):
    RotMatrix = parentBoneMatrix.to_3x3()
    nin = BinaryStream(normalData)
    out = BinaryStream()
    numVerts = len(normalData) // 12
    #print(quatMatrix)
    RotMatrix.invert()
    RotMatrix.transpose()
    # print(RotMatrix)
    for i in range(numVerts):
        normal = Vector(struct.unpack("<3f",nin.readBytes(12)))
        normal = RotMatrix @ normal
        normal.normalize()
        #print(normal)
        out.writeBytes(struct.pack("<3f", normal[0], normal[1], normal[2]))
    return out.getBuffer()


def getNormal(normalData):
    nin = BinaryStream(normalData)
    out = BinaryStream()
    numVerts = len(normalData) // 3
    for i in range(numVerts):
        nx = nin.readByte() / 128.0
        ny = nin.readByte() / 128.0
        nz = nin.readByte() / 128.0
        out.writeFloat(nx)
        out.writeFloat(ny)
        out.writeFloat(nz)
    return out.getBuffer()


class rGeomtry(object):

    def __init__(self, bs: BinaryStream, vertMat, hSkinBoneIDList, armature_obj, vertexGroupNames, \
                index, frame_list, atomic_list):
        self.bs = bs
        self.vertMat = vertMat
        self.matList = []
        self.hSkinBoneIDList = hSkinBoneIDList
        self.armature_obj = armature_obj
        self.vertexGroupNames = vertexGroupNames
        self.index = index
        self.frame_list = frame_list
        self.atomic_list = atomic_list
    def rGeometryStruct(self):
        geoStruct = RWChunk(self.bs)
        FormatFlags = self.bs.readUShort()
        numUV = self.bs.readByte()
        nativeFlags = self.bs.readByte()
        numFace = self.bs.readUInt()
        numVert = self.bs.readUInt()
        numMorphTargets = self.bs.readUInt()
        Tristrip = FormatFlags % 2
        Meshes = (FormatFlags & 3) >> 1
        Textured = (FormatFlags & 7) >> 2
        Prelit = (FormatFlags & 0xF) >> 3
        Normals = (FormatFlags & 0x1F) >> 4
        Light = (FormatFlags & 0x3F) >> 5
        ModulateMaterialColor = (FormatFlags & 0x7F) >> 6
        Textured_2 = (FormatFlags & 0xFF) >> 7
        MKSkinFlag = (FormatFlags & 0x100) == 0x100
        MtlIDList = []
        faceBuff = bytes()

        uv1s = []
        uv2s = []
        colors = None
        skinBoneIndices = []
        skinBoneWeights = []
        if nativeFlags != 1:
            if geoStruct.version < 0x34000:
                self.bs.seek(12, SEEK_CUR)  # skip surfaceProperties
            if Prelit == 1:
                colorData = self.bs.readBytes(numVert * 4)
                colors = []
                for c in range(numVert):
                    col = struct.unpack("<4B",colorData[c * 4: c * 4 + 4])
                    colors.append((col[0]/255,col[1]/255,col[2]/255,col[3]/255))
            if Textured == 1 or Textured_2 == 1:
                uv1Data = self.bs.readBytes(numVert * 8)
                for uv in range(numVert):
                    uv1 = struct.unpack("<2f",uv1Data[uv * 8:uv * 8 + 8])
                    uv1s.append((uv1[0], 1 - uv1[1]))
            if Textured_2 == 1:
                # uv1Data = self.bs.readBytes(numVert * 8)
                uv2Data = self.bs.readBytes(numVert * 8)
                for uv in range(numVert):
                    # uv1 = struct.unpack("<2f",uv1Data[uv * 8:uv * 8 + 8])
                    # uv1s.append((uv1[0], 1 - uv1[1]))
                    uv2 = struct.unpack("<2f",uv2Data[uv * 8:uv * 8 + 8])
                    uv2s.append((uv2[0], 1 - uv2[1]))
            if Meshes == 1:
                for i in range(numFace):
                    f1 = self.bs.readBytes(2)
                    f2 = self.bs.readBytes(2)
                    f3 = self.bs.readBytes(2)
                    MtlIDList.append(self.bs.readUShort())
                    faceBuff += f1
                    faceBuff += f2
                    faceBuff += f3
        morphTargetsVerticesList = []
        morphTargetsNormalsList = []
        normal_matrix = self.vertMat.inverted().transposed()
        vertex_transform_matrix = self.vertMat.to_3x3()
        for m in range(numMorphTargets):
            sphereXYZ = struct.unpack("3f", self.bs.readBytes(12))
            sphereRadius = self.bs.readFloat()
            positionFlag = self.bs.readUInt()
            normalFlag = self.bs.readUInt()

            vertBuff = []
            normBuff = []
            if nativeFlags != 1:
                if positionFlag == 1:
                    if geoStruct.version >= 0x34000:
                        pad16Len1 = ((self.bs.tell() + 15) & 0xFFFFFFF0) - self.bs.tell()
                        padl6Len2 = 16 - pad16Len1
                        self.bs.seek(pad16Len1, SEEK_CUR)
                    for i in range(numVert):
                        vert = Vector(struct.unpack("<3f",self.bs.readBytes(12)))
                        vert = vertex_transform_matrix @ vert
                        vertBuff.append(vert)
                    if geoStruct.version >= 0x34000:self.bs.seek(padl6Len2, SEEK_CUR)
                    morphTargetsVerticesList.append(vertBuff)
                if normalFlag == 1:
                    if geoStruct.version >= 0x34000:
                        pad16Len1 = ((self.bs.tell() + 15) & 0xFFFFFFF0) - self.bs.tell()
                        padl6Len2 = 16 - pad16Len1
                        self.bs.seek(pad16Len1, SEEK_CUR)
                    for i in range(numVert):
                        normal = Vector(struct.unpack("<3f",self.bs.readBytes(12)))
                        normal = normal_matrix @ normal
                        normal.normalize()
                        normBuff.append(normal)
                    if geoStruct.version >= 0x34000:self.bs.seek(padl6Len2, SEEK_CUR)
                    morphTargetsNormalsList.append(normBuff)
        matrialListHeader = RWChunk(self.bs)
        matDatas = self.bs.readBytes(matrialListHeader.chunkSize)
        rMatList = rMaterialList(matDatas)
        rMatList.getMaterial()
        matList = rMatList.matList
        texList = rMatList.texList
        for m in range(len(matList)):
            self.matList.append(matList[m])
        geoExtHeader = RWChunk(self.bs)
        geoExtEndOfs = self.bs.tell() + geoExtHeader.chunkSize

        haveSkin = 0
        haveBinMesh = 0
        while self.bs.tell() < geoExtEndOfs:
            header = RWChunk(self.bs)
            if header.chunkID == 0x50e:
                haveBinMesh = 1
                binMeshDatas = self.bs.readBytes(header.chunkSize)
            elif header.chunkID == 0x116:
                haveSkin = 1
                skinDatas = self.bs.readBytes(header.chunkSize)
            else:
                self.bs.seek(header.chunkSize, 1)
        if haveSkin:
            skin = rSkin(skinDatas, numVert, nativeFlags, geoStruct.version)
            skin.readSkin()
            # skinBoneIndices = skin.skinBoneIndices
            # skinBoneWeights = skin.skinBoneWeights
        if haveBinMesh:
            binMeshPLG = rBinMeshPLG(binMeshDatas, matList, nativeFlags)
            binMeshPLG.readFace()
        if haveSkin and nativeFlags == 0:
            # MKDA PS2
            if geoStruct.version < 0x34000 and skin.maxNumWeights == 0:
                newBids = bytes()
                for w in range(numVert):
                    weights = struct.unpack('4f',skin.boneWeights[w*16:w*16+16] )
                    b1,b2,b3,b4=(0,0,0,0)
                    if weights[0] > 0:
                        b1 = struct.unpack('B',skin.boneIndexs[w*4:w*4+1])[0]
                        b1 = skin.usedBoneIndexList[b1]
                    if weights[1] > 0:
                        b2 = struct.unpack('B',skin.boneIndexs[w*4+1:w*4+2])[0]
                        b2 = skin.usedBoneIndexList[b2]
                    if weights[2] > 0:
                        b3 = struct.unpack('B',skin.boneIndexs[w*4+2:w*4+3])[0]
                        b3 = skin.usedBoneIndexList[b3]
                    if weights[3] > 0:
                        b4 = struct.unpack('B',skin.boneIndexs[w*4+3:w*4+4])[0]
                        b4 = skin.usedBoneIndexList[b4]
                    newBids += struct.pack("4B",b1,b2,b3,b4)
                    skinBoneIndices.append((b1, b2, b3, b4))
                    skinBoneWeights.append(weights)
            # MKA Morph targets
            elif haveBinMesh and rMatList.useBonePalette:
                vertMatIDs = [0] * numVert
                for vertID,matID in zip(binMeshPLG.faceIndices,binMeshPLG.indicesMatIDs):
                    vertMatIDs[vertID] = matID
                # print(vertMatIDs)
                newBids = bytes()
                for w in range(numVert):
                    weights = struct.unpack('4f',skin.boneWeights[w*16:w*16+16] )
                    matID = vertMatIDs[w]
                    b1,b2,b3,b4=(0,0,0,0)
                    if weights[0] > 0:
                        b1 = struct.unpack('B',skin.boneIndexs[w*4:w*4+1])[0]
                        b1 = rMatList.MKMaterialSkinBonePalette[matID][b1]
                    if weights[1] > 0:
                        b2 = struct.unpack('B',skin.boneIndexs[w*4+1:w*4+2])[0]
                        b2 = rMatList.MKMaterialSkinBonePalette[matID][b2]
                    if weights[2] > 0:
                        b3 = struct.unpack('B',skin.boneIndexs[w*4+2:w*4+3])[0]
                        b3 = rMatList.MKMaterialSkinBonePalette[matID][b3]
                    if weights[3] > 0:
                        b4 = struct.unpack('B',skin.boneIndexs[w*4+3:w*4+4])[0]
                        b4 = rMatList.MKMaterialSkinBonePalette[matID][b4]
                    newBids += struct.pack("4B",b1,b2,b3,b4)
                    skinBoneIndices.append((b1, b2, b3, b4))
                    skinBoneWeights.append(weights)
        # print("read geo chunk...")
        if not nativeFlags:
            if Meshes:
                mesh = bpy.data.meshes.new("Mesh")
                obj = bpy.data.objects.new("Mesh",mesh)
                bpy.context.scene.collection.objects.link(obj)
                bpy.context.view_layer.objects.active = obj
                obj.select_set(True)
                bm = bmesh.new()

                # Vertex
                for v in morphTargetsVerticesList[0]:
                    bm.verts.new(v)
                bm.to_mesh(mesh)

                # Face
                bm.verts.ensure_lookup_table()
                for f in binMeshPLG.faces:
                    bm.faces.new([bm.verts[fi] for fi in f])
                bm.to_mesh(mesh)

                # Material 添加多维材质并导入显示纹理
                names = []
                if self.matList:
                    for mat in self.matList:
                        if mat.name not in names:
                            names.append(mat.name)
                            obj.data.materials.append(mat)

                # Set Face material index 为每个面指定材质ID
                for f,matID in zip(bm.faces,binMeshPLG.facesMaterialIndices):
                    matName = self.matList[matID].name
                    for m in range(len(obj.data.materials)):
                        if matName == obj.data.materials[m].name:
                            matID = m
                            break
                    f.material_index = matID
                bm.to_mesh(mesh)

                # UV
                if Textured or Textured_2:
                    uv_layer = bm.loops.layers.uv.verify()
                    bm.faces.ensure_lookup_table()
                    for face in bm.faces:
                        for loop in face.loops:
                            loop[uv_layer].uv = uv1s[loop.vert.index]
                    bm.to_mesh(mesh)

                # Normals
                if Normals:
                    mesh.normals_split_custom_set_from_vertices(morphTargetsNormalsList[0])
                    mesh.use_auto_smooth = True

                # Colors
                if Prelit:
                    vcol_layer = mesh.vertex_colors.new()
                    for loop,col in zip(mesh.loops, vcol_layer.data):
                        col.color = colors[loop.vertex_index]

                # Skin Bone Indices Weights
                if haveSkin:
                    vertexID = 0
                    for boneids,weights in zip(skinBoneIndices,skinBoneWeights):
                        for boneid,weight in zip(boneids,weights):
                            if weight != 0:
                                #if boneid >= len(self.vertexGroupNames):
                                #print(boneid,len(self.vertexGroupNames))
                                groupName = self.vertexGroupNames[boneid]
                                if groupName not in obj.vertex_groups:
                                    obj.vertex_groups.new(name = groupName)
                                obj.vertex_groups[groupName].add([vertexID],weight,'ADD')
                        vertexID += 1

                # Skin
                if self.armature_obj and haveSkin:
                    armatureMod = obj.modifiers.new("Armature","ARMATURE")
                    armatureMod.object = self.armature_obj
                    obj.parent = self.armature_obj
                else:
                    obj.parent = self.frame_list.armature_obj
                    obj.parent_type = 'BONE'
                    for i,atomic in enumerate(self.atomic_list):
                        geo_index = atomic.geometryIndex
                        if geo_index == self.index:
                            # print(self.frame_list.boneInfoList[atomic.frameIndex].boneName)
                            obj.parent_bone = self.frame_list.boneInfoList[atomic.frameIndex].boneName
                            break
                # obj.rotation_euler = (1.570796,0,0)
                mesh.update()
                bm.free()
                if numMorphTargets > 1:
                    # Adding Basis shapekey
                    sk_basis = obj.shape_key_add(name = 'Basis', from_mix=False)
                    sk_basis.interpolation = 'KEY_LINEAR'
                    obj.data.shape_keys.use_relative = False

                    # Add morph targets
                    for m in range(numMorphTargets - 1):
                        morphName = "morph targets{:00d}".format(m + 1)
                        sk = obj.shape_key_add(name = morphName, from_mix=False)
                        sk.interpolation = 'KEY_LINEAR'
                        for i in range(numVert):
                            sk.data[i].co = morphTargetsVerticesList[m+1][i]
                    ''''
                    bm1 = bmesh.new()
                    bm1.from_mesh(mesh)
                    for m in range(numMorphTargets - 1):
                        morphName = "morph targets{:00d}".format(m + 1)
                        shape_lay = bm1.verts.layers.shape[morphName]
                        for vert,shape in zip(bm1.verts, morphTargetsVerticesList[m + 1]):
                            vert[shape_lay] = shape
                    bm1.to_mesh(mesh)'''

                # print("read mesh done!")
        if nativeFlags == 1 and geoStruct.chunkSize > 40:
            # print("Read MK PS2 native geometry chunk.")
            splitCount = len(binMeshPLG.matIdList)
            nativeChunkStartOffset = self.bs.tell()
            nativeChunkSize = 0
            for i in range(splitCount):
                dataSize = self.bs.readUInt()
                meshType = self.bs.readUInt()
                endOfs = self.bs.tell() + dataSize
                self.bs.seek(endOfs)
                nativeChunkSize += (dataSize + 8)
            # skinPlgBoneMap = []
            if MKSkinFlag:
                skinDataSize = geoStruct.chunkSize - 40 - nativeChunkSize
                skinDatas = self.bs.readBytes(skinDataSize)
                skin = rSkin(skinDatas,numVert,nativeFlags,geoStruct.version)
                skin.readSkin()
                # skinPlgBoneMap = skin.usedBoneIndexList
            skinPlgEndOffset = self.bs.tell()
            self.bs.seek(nativeChunkStartOffset)
            #natvieDatas = self.bs.readBytes(nativeChunkSize)
            MKPS2NativeDataPLG = rMKPS2NativeDataPLG(self.bs,matList,binMeshPLG,\
                self.vertMat,rMatList.MKMaterialSkinBonePalette,\
                MKSkinFlag,self.hSkinBoneIDList,rMatList.useBonePalette,\
                rMatList.MKMaterialList,self.armature_obj,self.vertexGroupNames,\
                self.index, self.frame_list, self.atomic_list)
            MKPS2NativeDataPLG.readMesh()
            self.bs.seek(skinPlgEndOffset)
            # print("read mesh done!")


class Atomic(object):
    def __init__(self):
        self.frameIndex = 0
        self.geometryIndex = 0


class rAtomicList(object):

    def __init__(self, datas, numAtomics):
        self.bs = BinaryStream(datas)
        self.numAtomics = numAtomics

    def rAtomicStruct(self):
        atomicList = []
        for i in range(self.numAtomics):
            header = RWChunk(self.bs)
            atomic = Atomic()
            atomic.frameIndex = self.bs.readUInt()
            atomic.geometryIndex = self.bs.readUInt()
            flags = self.bs.readUInt()
            unused = self.bs.readUInt()
            extHeader = RWChunk(self.bs)
            self.bs.seek(extHeader.chunkSize, 1)
            atomicList.append(atomic)
        return atomicList


InputName = None
# use_some_setting 是bool类型的导入选项
def Import(context, filepath):#, use_some_setting):
    global InputName
    InputName = filepath
    # ("running import dff...")
    f = open(filepath, 'rb')
    data = f.read()
    f.close()


    bs = BinaryStream(data)

    startTextureIndex = bs.readInt()
    endTextureIndex = bs.readInt()

    clumpHeader = RWChunk(bs)
    if clumpHeader.chunkID == 16:
        clump = Clump(bs)
        clump.ReadClump()

    return {'FINISHED'}
