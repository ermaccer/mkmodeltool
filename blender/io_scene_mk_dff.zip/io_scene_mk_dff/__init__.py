from bpy.types import Operator
from bpy_extras.io_utils import (
    ImportHelper,
    ExportHelper,
)
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    StringProperty,
)
import bpy
import os
from .material.rw_material import *
from bpy.utils import register_class, unregister_class
bl_info = {
    "name": "Import-Export Mortal Kombat .dff",
    "author": "Allen",
    "version": (1, 0),
    "blender": (3, 5, 0),
    "location": "File > Import-Export",
    "description": "Import Export dff model",
    "warning": "",
    "doc_url": "",
    "category": "Import-Export",
}



class ImportDFF(Operator, ImportHelper):
    """Import-Export Mortal Kombat PS2 DFF files"""
    bl_idname = "import_mortalkombat.dff"
    bl_label = "Import DFF"

    # ImportHelper mixin class uses this
    filename_ext = ".dff"

    filter_glob: StringProperty(
        default="*.dff",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )
    '''
    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    use_setting: BoolProperty(
        name="Example Boolean",
        description="Example Tooltip",
        default=True,
    )
    
    type: EnumProperty(
        name="Example Enum",
        description="Choose between two items",
        items=(
            ('OPT_A', "First Option", "Description one"),
            ('OPT_B', "Second Option", "Description two"),
        ),
        default='OPT_A',
    )
    '''

    def execute(self, context):
        from .mk_dff_import import Import
        return Import(context, self.filepath)#, self.use_setting)

class ExportDFF(Operator, ExportHelper):
    """This appears in the tooltip of the operator and in the generated docs"""
    bl_idname = "export_mortalkombat.dff"
    # important since its how bpy.ops.import_test.some_data is constructed


    bl_label = "Export DFF"

    # ExportHelper mixin class uses this
    filename_ext = ".dff"

    filter_glob: StringProperty(
        default="*.dff",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    use_setting: BoolProperty(
        name="Specify export type",
        description="Specify export type",
        default=True,
    )

    type: EnumProperty(
        name="Model Type",
        description="Choose between two items",
        items=(
            ('costume', "COSTUME", "Mesh type 128,129 Player skin model"),
            ('weapon', "WEAPON", "Mesh type 128,129 Weapon skin model"),
            ('reflect', "REFLECT", "Mesh type 130 Player Reflect / WEAPON_RF model"),
            ('decoy', "DECOY","Mesh type 131 Player DECOY model"),
            ('npc', "NPC","Mesh type 131 NPC model"),
            ('background', "BACKGROUND", "Mesh type 137 Stage model"),
            ('type0', "Mesh type 0", "Mesh type 0 Weapon / Stage model"),
        ),
        default='costume',
    )

    def execute(self, context):
        from .mk_dff_export import Export
        return Export(context, self.filepath, self.use_setting, self.type)

# Only needed if you want to add into a dynamic menu.
def menu_func_import(self, context):
    self.layout.operator(ImportDFF.bl_idname, text="MK PS2 (.dff)")

# Only needed if you want to add into a dynamic menu
def menu_func_export(self, context):
    self.layout.operator(ExportDFF.bl_idname, text="MK PS2 (.dff)")

# Class list to register
_classes = [
    RW_Material_Props,
    RW_Material_Panel,
    MK_Material_Props,
    MK_Material_Panel,
]
def register():
    # Register all the classes
    for cls in _classes:
        register_class(cls)
    bpy.utils.register_class(ImportDFF)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.utils.register_class(ExportDFF)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

def unregister():
    bpy.utils.unregister_class(ImportDFF)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.utils.unregister_class(ExportDFF)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    for cls in _classes:
        unregister_class(cls)

if __name__ == "__main__":
    register()

clearConsole = lambda: os.system('cls' if os.name in ('nt', 'dos') else 'clear')
clearConsole()