1. Put the plugin to the your blender "Blender Foundation\Blender 4.0\4.0\scripts\addons" directory.
2.Go into the blender preferences, either by clicking on Main Header>Edit>Preferences or by changing an editor type to 'preferences'. 
Go to the 'Add-ons' category, Find "Import Export Mortal Kombat. dff" from the list and enable it (check box).